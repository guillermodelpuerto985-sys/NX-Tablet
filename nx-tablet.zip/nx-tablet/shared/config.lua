Config = {}

-- ─────────────────────────────────────────────────────────────────────────────
--  Framework
-- ─────────────────────────────────────────────────────────────────────────────
Config.Framework = 'auto'   -- 'auto' | 'esx' | 'qb'
Config.Target    = 'auto'   -- 'auto' | 'ox_target' | 'qb-target' (para la boombox)

-- ─────────────────────────────────────────────────────────────────────────────
--  Apertura
-- ─────────────────────────────────────────────────────────────────────────────
Config.ItemName    = 'tablet'   -- item usable que abre la tablet (ya existe en ox_inventory)
Config.RequireItem = true       -- el comando /tablet exige llevar el item
Config.OpenCommand = 'tablet'   -- nil para desactivar
Config.OpenKey     = nil        -- p. ej. 'F2' (nil para desactivar)

-- ─────────────────────────────────────────────────────────────────────────────
--  Prop en la mano (nativa del juego, no hace falta streamear nada)
-- ─────────────────────────────────────────────────────────────────────────────
Config.Prop = {
    Model    = 'prop_cs_tablet',
    Bone     = 60309,                         -- mano izquierda
    Offset   = { x = 0.03, y = 0.002, z = -0.0 },
    Rotation = { x = 10.0, y = 160.0, z = 0.0 },
    Anim     = { Dict = 'amb@code_human_in_bus_passenger_idles@female@tablet@base', Name = 'base', Flag = 49 },
}

-- ─────────────────────────────────────────────────────────────────────────────
--  Cámara / galería
--  Necesita el recurso `screenshot-basic`. Si rellenas UploadUrl las fotos se
--  suben a ese servicio (Fivemanage, webhook de Discord...) y en la base de
--  datos solo se guarda el enlace. Sin UploadUrl la foto se guarda entera en
--  MySQL (base64), por eso MaxLocalPhotos es bajo.
-- ─────────────────────────────────────────────────────────────────────────────
Config.Camera = {
    UploadUrl      = '',          -- p. ej. 'https://api.fivemanage.com/api/image'
    UploadField    = 'file',
    UploadHeaders  = {},          -- p. ej. { Authorization = 'TU_API_KEY' }
    Quality        = 0.6,
    MaxPhotos      = 80,          -- con UploadUrl
    MaxLocalPhotos = 20,          -- sin UploadUrl
    Zooms          = { 0.5, 1.0, 2.0, 3.0 },
}

-- ─────────────────────────────────────────────────────────────────────────────
--  Música (xsound). Solo se aceptan enlaces de YouTube: así ningún jugador
--  puede hacer que los clientes de los demás carguen URLs arbitrarias.
-- ─────────────────────────────────────────────────────────────────────────────
Config.Music = {
    -- Clave de YouTube Data API v3. Vacía = la búsqueda lee la página de
    -- resultados de YouTube (funciona sin clave, pero puede romperse si YouTube
    -- cambia su web).
    YoutubeApiKey  = '',
    TrendingQuery  = 'top hits 2026',
    DefaultVolume  = 0.5,
    -- Distancia a la que se oye cada salida de audio
    Distance = {
        ped = 8.0,    -- altavoz de la tablet
        veh = 14.0,   -- radio del coche por Bluetooth
        obj = 28.0,   -- boombox
    },
}

Config.Boombox = {
    ItemName = 'boombox',
    Model    = 'prop_boombox_01',
    CarryBone     = 57005,
    CarryOffset   = { x = 0.28, y = 0.0, z = -0.02 },
    CarryRotation = { x = 0.0, y = 270.0, z = 90.0 },
}

-- ─────────────────────────────────────────────────────────────────────────────
--  Banco
-- ─────────────────────────────────────────────────────────────────────────────
Config.Bank = {
    MaxTransfer = 1000000,
    Symbol      = '$',
}

-- ─────────────────────────────────────────────────────────────────────────────
--  Ajustes por defecto de cada jugador (el servidor solo acepta estas claves)
-- ─────────────────────────────────────────────────────────────────────────────
Config.Defaults = {
    wallpaper     = 'aurora',   -- id de fondo (ui/apps/settings.js) o URL de una foto
    frame         = 'none',     -- id de marco (ui/apps/settings.js)
    brightness    = 100,
    volume        = 60,         -- sonidos de la interfaz
    sounds        = true,
    notifications = true,
    airplane      = false,
    streamer      = false,
}

Config.WorldClocks = {
    { city = 'Madrid',   tz = 'Europe/Madrid' },
    { city = 'Londres',  tz = 'Europe/London' },
    { city = 'New York', tz = 'America/New_York' },
    { city = 'Tokio',    tz = 'Asia/Tokyo' },
}
