-- ============================================================================
--  NX Tablet -- puente ESX / QBCore
--  En QBCore, Bridge.GetPlayer devuelve un objeto con los MISMOS métodos que el
--  xPlayer de ESX (identifier, getName, getJob, getAccount...), así el resto
--  del recurso no necesita saber en qué framework está.
--  Cuentas: 'money' = efectivo (ESX) / 'cash' (QBCore); 'bank' en ambos.
-- ============================================================================

Bridge = {}

local framework, ESXObj, QBObj

local function running(name)
    local state = GetResourceState(name)
    return state == 'started' or state == 'starting'
end

function Bridge.Framework()
    if framework then return framework end
    if Config.Framework ~= 'auto' then
        framework = Config.Framework
    elseif running('es_extended') then
        framework = 'esx'
    elseif running('qb-core') then
        framework = 'qb'
    else
        error('nx-tablet: no se encuentra es_extended ni qb-core (Config.Framework)')
    end
    return framework
end

function Bridge.ESX()
    ESXObj = ESXObj or exports['es_extended']:getSharedObject()
    return ESXObj
end

function Bridge.QB()
    QBObj = QBObj or exports['qb-core']:GetCoreObject()
    return QBObj
end

-- ── Notificaciones (cliente) ────────────────────────────────────────────────
function Bridge.Notify(msg)
    msg = tostring(msg or '')
    if IsDuplicityVersion() then return end
    if Bridge.Framework() == 'esx' then
        Bridge.ESX().ShowNotification(msg)
    else
        Bridge.QB().Functions.Notify(msg)
    end
end

if IsDuplicityVersion() then
    -- ── Notificación a un jugador desde el servidor ─────────────────────────
    function Bridge.NotifyPlayer(src, msg)
        TriggerClientEvent('nx-tablet:notify', src, msg)
    end

    -- ── Items usables ───────────────────────────────────────────────────────
    function Bridge.RegisterUsableItem(item, cb)
        if Bridge.Framework() == 'esx' then
            Bridge.ESX().RegisterUsableItem(item, cb)
        else
            Bridge.QB().Functions.CreateUseableItem(item, function(src) cb(src) end)
        end
    end

    -- ── Jugador con interfaz de xPlayer ─────────────────────────────────────
    local function qbAccount(name)
        return name == 'money' and 'cash' or name
    end

    local function wrapQB(p)
        local pd = p.PlayerData
        local ci = pd.charinfo or {}
        return {
            source = pd.source,
            identifier = pd.citizenid,
            getName = function() return ('%s %s'):format(ci.firstname or '', ci.lastname or '') end,
            getJob = function()
                local grade = pd.job.grade or {}
                return { name = pd.job.name, label = pd.job.label, grade_label = grade.name }
            end,
            getAccount = function(name) return { money = p.Functions.GetMoney(qbAccount(name)) or 0 } end,
            addAccountMoney = function(name, amount) p.Functions.AddMoney(qbAccount(name), amount, 'nx-tablet') end,
            removeAccountMoney = function(name, amount) p.Functions.RemoveMoney(qbAccount(name), amount, 'nx-tablet') end,
            getInventoryItem = function(item)
                local entry = p.Functions.GetItemByName(item)
                return { count = entry and (entry.amount or entry.count) or 0 }
            end,
            addInventoryItem = function(item, count) p.Functions.AddItem(item, count or 1) end,
            removeInventoryItem = function(item, count) p.Functions.RemoveItem(item, count or 1) end,
            -- Datos de la ficha (en QBCore están en charinfo, no en la tabla users)
            profile = function()
                return { dob = ci.birthdate, sex = ci.gender == 1 and 'f' or 'm', height = nil }
            end,
        }
    end

    function Bridge.GetPlayer(src)
        if Bridge.Framework() == 'esx' then
            return Bridge.ESX().GetPlayerFromId(src)
        end
        local p = Bridge.QB().Functions.GetPlayer(tonumber(src) or -1)
        return p and wrapQB(p) or nil
    end

    -- Ficha del personaje: ESX la guarda en `users`, QBCore en charinfo
    function Bridge.Profile(xPlayer)
        if xPlayer.profile then return xPlayer.profile() end
        local row = MySQL.single.await('SELECT dateofbirth, sex, height FROM users WHERE identifier = ?', { xPlayer.identifier }) or {}
        return { dob = row.dateofbirth, sex = row.sex, height = row.height }
    end
else
    RegisterNetEvent('nx-tablet:notify', Bridge.Notify)
end
