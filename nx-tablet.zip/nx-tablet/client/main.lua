-- ============================================================================
--  NX Tablet -- núcleo de cliente
--  Abre/cierra la interfaz, sostiene la prop y hace de puente NUI <-> servidor.
--  Las peticiones de la UI van al servidor por `nx-tablet:req` (ox_lib); las
--  que solo necesitan el cliente (cámara, dispositivos de audio...) las
--  registran los demás archivos en `ClientActions`.
-- ============================================================================

local isOpen = false
local prop = nil
ClientActions = {}

Tablet = {
    isOpen = function() return isOpen end,
}

-- ── Prop + animación ────────────────────────────────────────────────────────
local function attachProp()
    local c = Config.Prop
    local ped = cache.ped

    local ok, model = pcall(lib.requestModel, c.Model, 2000)
    if ok and model then
        prop = CreateObject(model, GetEntityCoords(ped), true, true, false)
        AttachEntityToEntity(prop, ped, GetPedBoneIndex(ped, c.Bone),
            c.Offset.x, c.Offset.y, c.Offset.z, c.Rotation.x, c.Rotation.y, c.Rotation.z,
            true, true, false, true, 1, true)
        SetModelAsNoLongerNeeded(model)
    end

    if c.Anim and pcall(lib.requestAnimDict, c.Anim.Dict, 2000) then
        TaskPlayAnim(ped, c.Anim.Dict, c.Anim.Name, 3.0, -3.0, -1, c.Anim.Flag, 0, false, false, false)
    end
end

local function detachProp()
    if prop and DoesEntityExist(prop) then DeleteEntity(prop) end
    prop = nil
    local anim = Config.Prop.Anim
    if anim then StopAnimTask(cache.ped, anim.Dict, anim.Name, 1.0) end
end

-- Oculta/enseña la prop sin cerrar la tablet (la cámara la quita del plano)
function Tablet.setPropVisible(visible)
    if visible and isOpen and not prop then attachProp() elseif not visible then detachProp() end
end

-- ── Apertura / cierre ───────────────────────────────────────────────────────
local function open()
    if isOpen or IsPedFatallyInjured(cache.ped) or IsPauseMenuActive() then return end

    local boot = lib.callback.await('nx-tablet:req', false, 'boot', {})
    if not boot or not boot.ok then
        if boot and boot.error then Bridge.Notify(boot.error) end
        return
    end

    isOpen = true
    SetNuiFocus(true, true)
    attachProp()
    SendNUIMessage({ action = 'open', boot = boot })
end

local function close()
    if not isOpen then return end
    isOpen = false
    SetNuiFocus(false, false)
    detachProp()
    SendNUIMessage({ action = 'close' })
end

Tablet.open = open
Tablet.close = close

-- La cámara suelta el foco del ratón para poder mirar alrededor y lo recupera al salir
function Tablet.focus(on)
    if isOpen then SetNuiFocus(on, on) end
end

RegisterNetEvent('nx-tablet:open', open)

RegisterNUICallback('close', function(_, cb)
    close()
    cb({ ok = true })
end)

RegisterNUICallback('req', function(data, cb)
    if type(data) ~= 'table' or type(data.action) ~= 'string' then return cb({ ok = false }) end
    cb(lib.callback.await('nx-tablet:req', false, data.action, data.payload or {}) or { ok = false })
end)

RegisterNUICallback('client', function(data, cb)
    local handler = type(data) == 'table' and ClientActions[data.action]
    if not handler then return cb({ ok = false, error = 'acción desconocida' }) end
    local ok, result = pcall(handler, data.payload or {})
    cb(ok and (result or { ok = true }) or { ok = false, error = tostring(result) })
end)

RegisterNUICallback('notify', function(data, cb)
    if type(data) == 'table' and data.text then Bridge.Notify(tostring(data.text)) end
    cb({ ok = true })
end)

-- Respuestas que el servidor manda por evento latente (fotos grandes)
RegisterNetEvent('nx-tablet:push', function(event, payload)
    SendNUIMessage({ action = 'push', event = event, payload = payload })
end)

-- ── Estado del mundo para la barra superior, el tiempo y las alarmas ────────
local WEATHER = {
    EXTRASUNNY = { 'Despejado', 26 }, CLEAR = { 'Despejado', 24 }, NEUTRAL = { 'Neutral', 22 },
    SMOG = { 'Niebla tóxica', 18 }, FOGGY = { 'Niebla', 15 }, OVERCAST = { 'Nublado', 19 },
    CLOUDS = { 'Nubes', 21 }, CLEARING = { 'Despejando', 22 }, RAIN = { 'Lluvia', 14 },
    THUNDER = { 'Tormenta', 13 }, SNOW = { 'Nieve', -2 }, BLIZZARD = { 'Ventisca', -6 },
    SNOWLIGHT = { 'Nieve ligera', 0 }, XMAS = { 'Navidad', -1 }, HALLOWEEN = { 'Halloween', 12 },
}
local weatherByHash = {}
for name, info in pairs(WEATHER) do weatherByHash[joaat(name)] = { name = name, label = info[1], temp = info[2] } end

CreateThread(function()
    while true do
        local w = weatherByHash[GetPrevWeatherTypeHashName()] or { name = 'CLEAR', label = 'Despejado', temp = 22 }
        local coords = GetEntityCoords(cache.ped)
        SendNUIMessage({
            action = 'status',
            status = {
                hours = GetClockHours(),
                minutes = GetClockMinutes(),
                weather = w.name,
                weatherLabel = w.label,
                temp = w.temp,
                wind = math.floor(GetWindSpeed() * 3.6 * 10) / 10,
                street = GetStreetNameFromHashKey(GetStreetNameAtCoord(coords.x, coords.y, coords.z)),
            },
        })
        Wait(1000)
    end
end)

-- ── Bloqueo de controles mientras está abierta ──────────────────────────────
CreateThread(function()
    while true do
        if isOpen then
            DisableControlAction(0, 200, true) -- ESC (menú de pausa)
            DisableControlAction(0, 199, true) -- P
            DisableControlAction(0, 24, true)  -- disparar
            DisableControlAction(0, 25, true)  -- apuntar
            DisableControlAction(0, 1, true)
            DisableControlAction(0, 2, true)
            Wait(0)
        else
            Wait(300)
        end
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if isOpen then SetNuiFocus(false, false) end
    detachProp()
end)

-- ── Comando, tecla y export ─────────────────────────────────────────────────
if Config.OpenCommand then
    RegisterCommand(Config.OpenCommand, open, false)
end

if Config.OpenKey then
    RegisterCommand('+nx-tablet', open, false)
    RegisterCommand('-nx-tablet', function() end, false)
    RegisterKeyMapping('+nx-tablet', 'Abrir la tablet', 'keyboard', Config.OpenKey)
end

-- Para ox_inventory: client = { export = 'nx-tablet.useTablet' }
exports('useTablet', function() open() end)
