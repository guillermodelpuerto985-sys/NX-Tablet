-- ============================================================================
--  NX Tablet -- música sincronizada (xsound)
--  El servidor tiene un stream por jugador: URL, volumen, segundo actual,
--  pausa y SALIDA (la tablet del jugador, un coche o una boombox). Aquí cada
--  cliente reproduce todos los streams y mueve el sonido con la entidad de su
--  salida, así todos oyen lo mismo en el mismo sitio.
-- ============================================================================

local xs = exports.xsound
local streams = {}            -- [owner serverId] = datos del servidor + receivedAt
local FAR = vector3(0.0, 0.0, -1000.0)

local function soundId(owner) return 'nxtab_' .. owner end

local function entityOf(target)
    if not target or not target.net or not NetworkDoesNetworkIdExist(target.net) then return nil end
    local ent = NetworkGetEntityFromNetworkId(target.net)
    return (ent ~= 0 and DoesEntityExist(ent)) and ent or nil
end

-- Segundo por el que debería ir la canción ahora mismo
local function currentTime(data)
    if data.paused then return data.time end
    return data.time + (GetGameTimer() - data.receivedAt) / 1000
end

local function destroy(owner)
    local id = soundId(owner)
    if xs:soundExists(id) then xs:Destroy(id) end
end

local function startSound(owner, data)
    local id = soundId(owner)
    destroy(owner)

    local ent = entityOf(data.target)
    xs:PlayUrlPos(id, data.url, data.volume, ent and GetEntityCoords(ent) or FAR, false)
    xs:Distance(id, data.distance)

    -- xsound solo deja saltar a un segundo cuando el vídeo ya ha cargado
    xs:onPlayStart(id, function()
        local now = streams[owner]
        if not now then return end
        local t = currentTime(now)
        if t > 1 then xs:setTimeStamp(id, t) end
        if now.paused then xs:Pause(id) end
    end)

    if owner == cache.serverId then
        xs:onPlayEnd(id, function() SendNUIMessage({ action = 'music:ended' }) end)
    end
end

RegisterNetEvent('nx-tablet:stream', function(owner, data)
    if not data then
        streams[owner] = nil
        destroy(owner)
        if owner == cache.serverId then SendNUIMessage({ action = 'music:state', state = false }) end
        return
    end

    local previous = streams[owner]
    data.receivedAt = GetGameTimer()
    streams[owner] = data

    local id = soundId(owner)
    if not previous or previous.url ~= data.url or previous.startId ~= data.startId or not xs:soundExists(id) then
        startSound(owner, data)
    else
        xs:setVolume(id, data.volume)
        xs:Distance(id, data.distance)
        if data.seek then xs:setTimeStamp(id, data.time) end
        if data.paused then xs:Pause(id) else xs:Resume(id) end
    end

    if owner == cache.serverId then SendNUIMessage({ action = 'music:state', state = data }) end
end)

-- Al entrar en el servidor (o reiniciar el recurso) pedimos lo que ya suena
CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(500) end
    TriggerServerEvent('nx-tablet:streams:sync')
end)

-- El sonido sigue a su salida (jugador, coche o boombox)
CreateThread(function()
    while true do
        for owner in pairs(streams) do
            local id = soundId(owner)
            if xs:soundExists(id) then
                local ent = entityOf(streams[owner].target)
                xs:Position(id, ent and GetEntityCoords(ent) or FAR)
            end
        end
        Wait(200)
    end
end)

-- Progreso de MI canción para la barra del reproductor
CreateThread(function()
    while true do
        local id = soundId(cache.serverId)
        if streams[cache.serverId] and xs:soundExists(id) then
            SendNUIMessage({
                action = 'music:progress',
                time = xs:getTimeStamp(id) or 0,
                duration = xs:getMaxDuration(id) or 0,
            })
        end
        Wait(1000)
    end
end)

-- Salidas de audio disponibles para el panel «Dispositivos»
ClientActions['music:devices'] = function()
    local list = { { kind = 'ped', label = 'Altavoz de la tablet', sub = 'Integrado' } }

    local veh = cache.vehicle
    if veh then
        list[#list + 1] = {
            kind = 'veh',
            net = NetworkGetNetworkIdFromEntity(veh),
            label = GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(veh))),
            sub = 'Radio Bluetooth · ' .. GetVehicleNumberPlateText(veh),
        }
    end

    local coords = GetEntityCoords(cache.ped)
    local model = joaat(Config.Boombox.Model)
    for _, obj in ipairs(GetGamePool('CObject')) do
        if GetEntityModel(obj) == model and #(GetEntityCoords(obj) - coords) < 6.0 and NetworkGetEntityIsNetworked(obj) then
            local owner = Entity(obj).state.nxtOwner
            if owner == cache.serverId or owner == 0 then
                list[#list + 1] = { kind = 'obj', net = NetworkGetNetworkIdFromEntity(obj), label = 'Boombox', sub = 'Altavoz Bluetooth' }
            end
        end
    end

    local mine = streams[cache.serverId]
    return { ok = true, devices = list, current = mine and mine.target or nil }
end

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for owner in pairs(streams) do destroy(owner) end
end)
