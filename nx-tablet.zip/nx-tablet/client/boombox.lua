-- ============================================================================
--  NX Tablet -- boombox (altavoz Bluetooth)
--  Se coloca usando el item, y con ox_target se conecta a la tablet, se lleva
--  en la mano o se recoge. El dueño va en el state bag `nxtOwner` de la prop
--  (0 = su dueño se desconectó y cualquiera puede recogerla).
-- ============================================================================

local carried = nil

local function placeInFront(obj)
    local ped = cache.ped
    local pos = GetOffsetFromEntityInWorldCoords(ped, 0.0, 0.7, 0.0)
    SetEntityCoords(obj, pos.x, pos.y, pos.z, false, false, false, false)
    SetEntityHeading(obj, GetEntityHeading(ped))
    PlaceObjectOnGroundProperly(obj)
    FreezeEntityPosition(obj, true)
end

local function crouchAnim()
    if pcall(lib.requestAnimDict, 'pickup_object', 1000) then
        TaskPlayAnim(cache.ped, 'pickup_object', 'pickup_low', 8.0, -8.0, 1000, 0, 0, false, false, false)
        Wait(700)
    end
end

RegisterNetEvent('nx-tablet:boombox:place', function()
    crouchAnim()
    local ok, model = pcall(lib.requestModel, Config.Boombox.Model, 2000)
    if not ok then return end

    local obj = CreateObject(model, GetEntityCoords(cache.ped), true, true, false)
    SetModelAsNoLongerNeeded(model)
    placeInFront(obj)

    local deadline = GetGameTimer() + 2000
    while not NetworkGetEntityIsNetworked(obj) and GetGameTimer() < deadline do Wait(0) end
    TriggerServerEvent('nx-tablet:boombox:placed', NetworkGetNetworkIdFromEntity(obj))
end)

local function control(ent)
    local deadline = GetGameTimer() + 1500
    NetworkRequestControlOfEntity(ent)
    while not NetworkHasControlOfEntity(ent) and GetGameTimer() < deadline do
        Wait(0)
        NetworkRequestControlOfEntity(ent)
    end
    return NetworkHasControlOfEntity(ent)
end

local function drop()
    if not carried then return end
    local obj = carried
    carried = nil
    lib.hideTextUI()
    if not DoesEntityExist(obj) or not control(obj) then return end
    DetachEntity(obj, true, true)
    crouchAnim()
    placeInFront(obj)
end

local function carry(obj)
    if carried or not control(obj) then return end
    local c = Config.Boombox
    carried = obj
    FreezeEntityPosition(obj, false)
    AttachEntityToEntity(obj, cache.ped, GetPedBoneIndex(cache.ped, c.CarryBone),
        c.CarryOffset.x, c.CarryOffset.y, c.CarryOffset.z, c.CarryRotation.x, c.CarryRotation.y, c.CarryRotation.z,
        true, true, false, true, 1, true)
    lib.showTextUI('[G] Dejar la boombox')

    CreateThread(function()
        while carried do
            if IsControlJustPressed(0, 47) or IsPedFatallyInjured(cache.ped) or cache.vehicle then drop() end
            Wait(0)
        end
    end)
end

local function canUse(entity)
    local owner = Entity(entity).state.nxtOwner
    return owner ~= nil and (owner == cache.serverId or owner == 0) and carried ~= entity
end

-- Cada opción recibe la entidad de la boombox
local OPTIONS = {
    {
        name = 'nxt_boombox_connect', icon = 'fa-brands fa-bluetooth-b', label = 'Conectar Bluetooth',
        run = function(entity)
            local res = lib.callback.await('nx-tablet:req', false, 'music:output',
                { kind = 'obj', net = NetworkGetNetworkIdFromEntity(entity) })
            Bridge.Notify(res and res.ok and 'Boombox conectada' or (res and res.error or 'No se pudo conectar'))
        end,
    },
    { name = 'nxt_boombox_carry', icon = 'fa-solid fa-hand', label = 'Llevar', run = carry },
    {
        name = 'nxt_boombox_pickup', icon = 'fa-solid fa-box', label = 'Recoger',
        run = function(entity)
            crouchAnim()
            TriggerServerEvent('nx-tablet:boombox:pickup', NetworkGetNetworkIdFromEntity(entity))
        end,
    },
}

-- ox_target si está; si no, qb-target (habitual en QBCore)
local function targetResource()
    if Config.Target ~= 'auto' then return Config.Target end
    return GetResourceState('ox_target') == 'started' and 'ox_target' or 'qb-target'
end

CreateThread(function()
    local target = targetResource()
    local opts = {}
    if target == 'ox_target' then
        for i, o in ipairs(OPTIONS) do
            opts[i] = { name = o.name, icon = o.icon, label = o.label, canInteract = canUse, onSelect = function(d) o.run(d.entity) end }
        end
        exports.ox_target:addModel(Config.Boombox.Model, opts)
    else
        for i, o in ipairs(OPTIONS) do
            opts[i] = { icon = o.icon, label = o.label, canInteract = canUse, action = function(entity) o.run(entity) end }
        end
        exports['qb-target']:AddTargetModel(Config.Boombox.Model, { options = opts, distance = 2.0 })
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if carried then lib.hideTextUI() end
    if targetResource() == 'ox_target' then
        exports.ox_target:removeModel(Config.Boombox.Model, { 'nxt_boombox_connect', 'nxt_boombox_carry', 'nxt_boombox_pickup' })
    else
        exports['qb-target']:RemoveTargetModel(Config.Boombox.Model, { 'Conectar Bluetooth', 'Llevar', 'Recoger' })
    end
end)
