-- ============================================================================
--  NX Tablet -- cámara
--  Trasera: cámara de script a la altura de la cabeza que sigue a la cámara de
--  juego (el ratón mira alrededor) con zoom por FOV. Frontal: selfie nativa del
--  móvil de GTA. La foto se hace con screenshot-basic.
--
--  Controles: CLIC / ESPACIO foto · RUEDA zoom · E cambiar cámara · RETROCESO salir
-- ============================================================================

local active = false
local selfie = false
local cam = nil
local zoomIndex = 2
local busy = false

local function frontCam(on)
    return Citizen.InvokeNative(0x2491A93618B7D838, on) -- CellFrontCamActivate
end

local function rotToDir(rot)
    local x, z = math.rad(rot.x), math.rad(rot.z)
    return vector3(-math.sin(z) * math.cos(x), math.cos(z) * math.cos(x), math.sin(x))
end

local function sendState(extra)
    local state = { action = 'camera', on = active, selfie = selfie, zoom = Config.Camera.Zooms[zoomIndex] }
    for k, v in pairs(extra or {}) do state[k] = v end
    SendNUIMessage(state)
end

local function stopSelfie()
    frontCam(false)
    CellCamActivate(false, false)
    DestroyMobilePhone()
end

local function stopRear()
    if not cam then return end
    RenderScriptCams(false, false, 0, true, true)
    DestroyCam(cam, false)
    cam = nil
end

local function setSelfie(on)
    selfie = on
    if on then
        stopRear()
        CreateMobilePhone(0)
        CellCamActivate(true, true)
        frontCam(true)
    else
        stopSelfie()
        cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
        RenderScriptCams(true, false, 0, true, true)
    end
    sendState()
end

-- Devuelve la URL (o data URI) de la foto, o nil
local function capture()
    if GetResourceState('screenshot-basic') ~= 'started' then
        Bridge.Notify('La cámara necesita el recurso screenshot-basic')
        return nil
    end

    local c = Config.Camera
    local p = promise.new()
    local opts = { encoding = 'jpg', quality = c.Quality }

    if c.UploadUrl and c.UploadUrl ~= '' then
        opts.headers = c.UploadHeaders
        exports['screenshot-basic']:requestScreenshotUpload(c.UploadUrl, c.UploadField, opts, function(raw)
            local ok, d = pcall(json.decode, raw)
            d = ok and type(d) == 'table' and d or {}
            -- Fivemanage / webhook de Discord / genérico
            p:resolve(d.url or (d.data and d.data.url) or (d.attachments and d.attachments[1] and d.attachments[1].url))
        end)
    else
        exports['screenshot-basic']:requestScreenshot(opts, function(data) p:resolve(data) end)
    end

    return Citizen.Await(p)
end

local function takePhoto()
    if busy then return end
    busy = true
    sendState({ hidden = true })   -- la interfaz se aparta para no salir en la foto
    Wait(80)
    local url = capture()
    sendState({ hidden = false, flash = url ~= nil })

    if url and url:sub(1, 5) == 'data:' then
        TriggerLatentServerEvent('nx-tablet:gallery:upload', 200000, url)
    elseif url then
        lib.callback.await('nx-tablet:req', false, 'gallery:add', { url = url })
    elseif GetResourceState('screenshot-basic') == 'started' then
        Bridge.Notify('No se pudo guardar la foto')
    end
    busy = false
end

local function stop()
    if not active then return end
    active = false
    if selfie then stopSelfie() else stopRear() end
    selfie = false
    Tablet.setPropVisible(true)
    Tablet.focus(true)
    DisplayRadar(true)
    sendState()
end

local function start()
    if active then return end
    active = true
    zoomIndex = 2
    Tablet.setPropVisible(false)
    Tablet.focus(false)
    setSelfie(false)

    CreateThread(function()
        while active do
            local ped = cache.ped
            HideHudAndRadarThisFrame()
            for _, control in ipairs({ 14, 15, 16, 17, 22, 24, 25, 37, 38, 177, 199, 200 }) do
                DisableControlAction(0, control, true)
            end

            if cam then
                local rot = GetGameplayCamRot(2)
                local head = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0)
                SetCamCoord(cam, head + rotToDir(rot) * 0.35)
                SetCamRot(cam, rot.x, rot.y, rot.z, 2)
                SetCamFov(cam, math.min(110.0, GetGameplayCamFov() / Config.Camera.Zooms[zoomIndex]))
            end

            if IsDisabledControlJustPressed(0, 24) or IsDisabledControlJustPressed(0, 22) then
                CreateThread(takePhoto)
            elseif IsDisabledControlJustPressed(0, 15) or IsDisabledControlJustPressed(0, 17) then
                zoomIndex = math.min(#Config.Camera.Zooms, zoomIndex + 1); sendState()
            elseif IsDisabledControlJustPressed(0, 14) or IsDisabledControlJustPressed(0, 16) then
                zoomIndex = math.max(1, zoomIndex - 1); sendState()
            elseif IsDisabledControlJustPressed(0, 38) then
                setSelfie(not selfie)
            elseif IsDisabledControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 200)
                or IsPedFatallyInjured(ped) or not Tablet.isOpen() then
                stop()
            end
            Wait(0)
        end
    end)
end

ClientActions.camera = function()
    start()
    return { ok = true }
end

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then stop() end
end)
