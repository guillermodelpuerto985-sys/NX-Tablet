fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nx-tablet'
author 'NX'
description 'NX Tablet - tablet para ESX y QBCore: cámara, galería, reloj, notas, banco, perfil y música con altavoces Bluetooth (tablet, coche y boombox)'
version '1.1.0'

-- es_extended o qb-core: se detecta solo (Config.Framework)
dependencies {
    'oxmysql',
    'ox_lib',
    'xsound',
}

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua',
    'shared/bridge.lua',
}

client_scripts {
    'client/main.lua',
    'client/camera.lua',
    'client/music.lua',
    'client/boombox.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua',
    'server/music.lua',
}

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/style.css',
    'ui/core.js',
    'ui/apps/*.js',
}
