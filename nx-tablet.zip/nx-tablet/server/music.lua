-- ============================================================================
--  NX Tablet -- música: un stream por jugador, búsqueda en YouTube, playlists
--  (propias y compartidas) y boomboxes.
-- ============================================================================

local streams = {}     -- [src] = { track, volume, offset, startedAt, paused, target, startId }
local boomboxes = {}   -- [netId] = owner src (0 = dueño desconectado)
local lastSearch = {}
local startCounter = 0

local function str(value, max)
    if type(value) ~= 'string' then return '' end
    return value:sub(1, max)
end

-- ── Streams ─────────────────────────────────────────────────────────────────
local function elapsed(s)
    if s.paused then return s.offset end
    return s.offset + (os.time() - s.startedAt)
end

local function wire(s, seek)
    return {
        url = 'https://www.youtube.com/watch?v=' .. s.track.id,
        track = s.track,
        volume = s.volume,
        time = elapsed(s),
        paused = s.paused,
        seek = seek or nil,
        target = s.target,
        distance = Config.Music.Distance[s.target.kind] or 10.0,
        startId = s.startId,
    }
end

local function publish(src, seek)
    local s = streams[src]
    TriggerClientEvent('nx-tablet:stream', -1, src, s and wire(s, seek) or nil)
end

local function pedTarget(src)
    return { kind = 'ped', net = NetworkGetNetworkIdFromEntity(GetPlayerPed(src)) }
end

RegisterNetEvent('nx-tablet:streams:sync', function()
    local src = source
    for owner, s in pairs(streams) do
        TriggerClientEvent('nx-tablet:stream', src, owner, wire(s))
    end
end)

-- Pista que viene de la UI: solo vídeos de YouTube (id de 11 caracteres)
local function cleanTrack(t)
    if type(t) ~= 'table' or type(t.id) ~= 'string' or not t.id:match('^[%w_%-]+$') or #t.id ~= 11 then return nil end
    return {
        id = t.id,
        title = str(t.title, 120),
        author = str(t.author, 60),
        thumb = ('https://i.ytimg.com/vi/%s/mqdefault.jpg'):format(t.id),
        duration = str(t.duration, 10),
    }
end

Routes['music:play'] = function(src, _, p)
    local track = cleanTrack(p.track)
    if not track then return { ok = false, error = 'Canción no válida' } end

    local previous = streams[src]
    startCounter = startCounter + 1
    streams[src] = {
        track = track,
        volume = previous and previous.volume or Config.Music.DefaultVolume,
        offset = 0,
        startedAt = os.time(),
        paused = false,
        target = previous and previous.target or pedTarget(src),
        startId = startCounter,
    }
    publish(src)
    return { ok = true }
end

Routes['music:pause'] = function(src)
    local s = streams[src]
    if not s or s.paused then return { ok = true } end
    s.offset = elapsed(s)
    s.paused = true
    publish(src)
    return { ok = true }
end

Routes['music:resume'] = function(src)
    local s = streams[src]
    if not s or not s.paused then return { ok = true } end
    s.paused = false
    s.startedAt = os.time()
    publish(src)
    return { ok = true }
end

Routes['music:seek'] = function(src, _, p)
    local s = streams[src]
    if not s then return { ok = false } end
    s.offset = math.max(0, math.floor(tonumber(p.time) or 0))
    s.startedAt = os.time()
    publish(src, true)
    return { ok = true }
end

Routes['music:volume'] = function(src, _, p)
    local s = streams[src]
    if not s then return { ok = false } end
    s.volume = math.max(0.0, math.min(1.0, tonumber(p.volume) or s.volume))
    publish(src)
    return { ok = true }
end

Routes['music:stop'] = function(src)
    streams[src] = nil
    publish(src)
    return { ok = true }
end

-- Cambia la salida de audio validando que el jugador puede usarla
Routes['music:output'] = function(src, _, p)
    local s = streams[src]
    if not s then return { ok = false, error = 'No hay nada sonando' } end

    local ped = GetPlayerPed(src)
    local target

    if p.kind == 'ped' then
        target = pedTarget(src)
    elseif p.kind == 'veh' then
        local veh = GetVehiclePedIsIn(ped, false)
        if veh == 0 or NetworkGetNetworkIdFromEntity(veh) ~= tonumber(p.net) then
            return { ok = false, error = 'Tienes que estar dentro del vehículo' }
        end
        target = { kind = 'veh', net = tonumber(p.net) }
    elseif p.kind == 'obj' then
        local net = tonumber(p.net)
        local owner = net and boomboxes[net]
        local ent = net and NetworkGetEntityFromNetworkId(net)
        if owner == nil or (owner ~= src and owner ~= 0) or not ent or ent == 0
            or #(GetEntityCoords(ent) - GetEntityCoords(ped)) > 8.0 then
            return { ok = false, error = 'No puedes conectarte a esa boombox' }
        end
        target = { kind = 'obj', net = net }
    else
        return { ok = false }
    end

    s.target = target
    publish(src)
    return { ok = true, target = target }
end

-- ── Búsqueda en YouTube ─────────────────────────────────────────────────────
local function urlencode(s)
    return (s:gsub('[^%w%-_%.~]', function(c) return ('%%%02X'):format(c:byte()) end))
end

local function httpGet(url)
    local p = promise.new()
    PerformHttpRequest(url, function(code, body) p:resolve({ code = code, body = body }) end, 'GET', '',
        { ['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', ['Accept-Language'] = 'es-ES,es;q=0.9' })
    return Citizen.Await(p)
end

local function unescape(s)
    return (s or ''):gsub('&amp;', '&'):gsub('&quot;', '"'):gsub('&#39;', "'"):gsub('&lt;', '<'):gsub('&gt;', '>')
end

local function searchApi(q)
    local res = httpGet(('https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=24&q=%s&key=%s')
        :format(urlencode(q), Config.Music.YoutubeApiKey))
    local ok, data = pcall(json.decode, res.body or '')
    local out = {}
    for _, item in ipairs(ok and data and data.items or {}) do
        out[#out + 1] = cleanTrack({ id = item.id.videoId, title = unescape(item.snippet.title), author = unescape(item.snippet.channelTitle) })
    end
    return out
end

-- shortcut: lee el JSON `ytInitialData` de la página de resultados; si YouTube
-- cambia su web dejará de funcionar -> pon Config.Music.YoutubeApiKey.
local function searchScrape(q)
    local res = httpGet('https://www.youtube.com/results?sp=EgIQAQ%253D%253D&search_query=' .. urlencode(q))
    local raw = (res.body or ''):match('var ytInitialData%s*=%s*(%b{})')
    local ok, data = pcall(json.decode, raw or '')
    local out = {}
    if not ok or type(data) ~= 'table' then return out end

    local function walk(node)
        if #out >= 24 or type(node) ~= 'table' then return end
        local v = node.videoRenderer
        if type(v) == 'table' and v.videoId then
            out[#out + 1] = cleanTrack({
                id = v.videoId,
                title = v.title and v.title.runs and v.title.runs[1] and v.title.runs[1].text,
                author = v.ownerText and v.ownerText.runs and v.ownerText.runs[1] and v.ownerText.runs[1].text,
                duration = v.lengthText and v.lengthText.simpleText,
            })
            return
        end
        for _, child in pairs(node) do walk(child) end
    end
    walk(data)
    return out
end

Routes['music:search'] = function(src, _, p)
    local q = str(p.q, 100)
    if q == '' then return { ok = true, results = {} } end
    if lastSearch[src] and GetGameTimer() - lastSearch[src] < 1500 then return { ok = false, error = 'Espera un momento' } end
    lastSearch[src] = GetGameTimer()

    -- Enlace pegado directamente
    local id = q:match('youtu%.be/([%w_%-]+)') or q:match('[?&]v=([%w_%-]+)') or q:match('/shorts/([%w_%-]+)')
    if id then
        local res = httpGet('https://www.youtube.com/oembed?format=json&url=' .. urlencode('https://www.youtube.com/watch?v=' .. id))
        local ok, data = pcall(json.decode, res.body or '')
        local track = cleanTrack({ id = id, title = ok and data and data.title or q, author = ok and data and data.author_name })
        return { ok = true, results = { track } }
    end

    local results = Config.Music.YoutubeApiKey ~= '' and searchApi(q) or searchScrape(q)
    return { ok = true, results = results }
end

-- ── Playlists ───────────────────────────────────────────────────────────────
local function decodeTracks(raw)
    local ok, data = pcall(json.decode, raw or '[]')
    return ok and type(data) == 'table' and data or {}
end

local function playlistsFor(identifier)
    local rows = MySQL.query.await([[SELECT id, identifier, owner_name, name, tracks, shared FROM nx_tablet_playlists
        WHERE identifier = ? OR shared = 1 ORDER BY id DESC LIMIT 60]], { identifier }) or {}
    for _, row in ipairs(rows) do
        row.tracks = decodeTracks(row.tracks)
        row.mine = row.identifier == identifier
        row.shared = row.shared == 1 or row.shared == true
        row.identifier = nil
    end
    return { ok = true, playlists = rows }
end

local function ownPlaylist(identifier, id)
    return MySQL.single.await('SELECT id, tracks FROM nx_tablet_playlists WHERE id = ? AND identifier = ?', { tonumber(id) or 0, identifier })
end

Routes['playlists:list'] = function(_, xPlayer) return playlistsFor(xPlayer.identifier) end

Routes['playlists:create'] = function(_, xPlayer, p)
    local name = str(p.name, 48)
    if name == '' then return { ok = false, error = 'Ponle un nombre' } end
    local count = MySQL.scalar.await('SELECT COUNT(*) FROM nx_tablet_playlists WHERE identifier = ?', { xPlayer.identifier }) or 0
    if count >= 25 then return { ok = false, error = 'Máximo 25 playlists' } end
    MySQL.insert.await('INSERT INTO nx_tablet_playlists (identifier, owner_name, name, tracks) VALUES (?, ?, ?, ?)',
        { xPlayer.identifier, str(xPlayer.getName(), 64), name, '[]' })
    return playlistsFor(xPlayer.identifier)
end

Routes['playlists:delete'] = function(_, xPlayer, p)
    MySQL.update.await('DELETE FROM nx_tablet_playlists WHERE id = ? AND identifier = ?', { tonumber(p.id) or 0, xPlayer.identifier })
    return playlistsFor(xPlayer.identifier)
end

Routes['playlists:share'] = function(_, xPlayer, p)
    MySQL.update.await('UPDATE nx_tablet_playlists SET shared = ? WHERE id = ? AND identifier = ?',
        { p.shared and 1 or 0, tonumber(p.id) or 0, xPlayer.identifier })
    return playlistsFor(xPlayer.identifier)
end

Routes['playlists:add'] = function(_, xPlayer, p)
    local row = ownPlaylist(xPlayer.identifier, p.id)
    local track = cleanTrack(p.track)
    if not row or not track then return { ok = false, error = 'No se pudo añadir' } end
    local tracks = decodeTracks(row.tracks)
    for _, t in ipairs(tracks) do
        if t.id == track.id then return playlistsFor(xPlayer.identifier) end
    end
    if #tracks >= 200 then return { ok = false, error = 'Playlist llena' } end
    tracks[#tracks + 1] = track
    MySQL.update.await('UPDATE nx_tablet_playlists SET tracks = ? WHERE id = ?', { json.encode(tracks), row.id })
    return playlistsFor(xPlayer.identifier)
end

Routes['playlists:remove'] = function(_, xPlayer, p)
    local row = ownPlaylist(xPlayer.identifier, p.id)
    if not row then return { ok = false } end
    local tracks = decodeTracks(row.tracks)
    for i, t in ipairs(tracks) do
        if t.id == p.trackId then table.remove(tracks, i); break end
    end
    MySQL.update.await('UPDATE nx_tablet_playlists SET tracks = ? WHERE id = ?', { json.encode(tracks), row.id })
    return playlistsFor(xPlayer.identifier)
end

-- ── Boombox ─────────────────────────────────────────────────────────────────
CreateThread(function()
    Bridge.RegisterUsableItem(Config.Boombox.ItemName, function(src)
        TriggerClientEvent('nx-tablet:boombox:place', src)
    end)
end)

RegisterNetEvent('nx-tablet:boombox:placed', function(net)
    local src = source
    local xPlayer = Bridge.GetPlayer(src)
    net = tonumber(net) or 0
    local ent = NetworkGetEntityFromNetworkId(net)
    if not ent or ent == 0 or GetEntityModel(ent) ~= joaat(Config.Boombox.Model) then return end

    if not xPlayer or not HasItem(xPlayer, Config.Boombox.ItemName) then
        DeleteEntity(ent)
        return
    end

    xPlayer.removeInventoryItem(Config.Boombox.ItemName, 1)
    boomboxes[net] = src
    Entity(ent).state:set('nxtOwner', src, true)
end)

local function releaseBoombox(net)
    for owner, s in pairs(streams) do
        if s.target.kind == 'obj' and s.target.net == net then
            s.target = pedTarget(owner)
            publish(owner)
        end
    end
    boomboxes[net] = nil
end

RegisterNetEvent('nx-tablet:boombox:pickup', function(net)
    local src = source
    net = tonumber(net)
    local owner = net and boomboxes[net]
    local xPlayer = Bridge.GetPlayer(src)
    local ent = net and NetworkGetEntityFromNetworkId(net)
    if not xPlayer or owner == nil or (owner ~= src and owner ~= 0) or not ent or ent == 0 then return end
    if #(GetEntityCoords(ent) - GetEntityCoords(GetPlayerPed(src))) > 4.0 then return end

    releaseBoombox(net)
    DeleteEntity(ent)
    xPlayer.addInventoryItem(Config.Boombox.ItemName, 1)
end)

AddEventHandler('playerDropped', function()
    local src = source
    lastSearch[src] = nil
    if streams[src] then
        streams[src] = nil
        publish(src)
    end
    -- Su boombox se queda en el suelo y cualquiera puede recogerla
    for net, owner in pairs(boomboxes) do
        if owner == src then
            boomboxes[net] = 0
            local ent = NetworkGetEntityFromNetworkId(net)
            if ent and ent ~= 0 then Entity(ent).state:set('nxtOwner', 0, true) end
        end
    end
end)

-- Al parar el recurso las boomboxes vuelven al inventario de su dueño
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for net, owner in pairs(boomboxes) do
        local ent = NetworkGetEntityFromNetworkId(net)
        if ent and ent ~= 0 then DeleteEntity(ent) end
        local xPlayer = owner ~= 0 and Bridge.GetPlayer(owner)
        if xPlayer then xPlayer.addInventoryItem(Config.Boombox.ItemName, 1) end
    end
end)
