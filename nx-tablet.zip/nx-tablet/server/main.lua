-- ============================================================================
--  NX Tablet -- servidor: router de peticiones, ajustes, notas, alarmas,
--  galería, banco y perfil. Las rutas de música están en server/music.lua.
-- ============================================================================

Routes = {}

local function now() return os.time() end

local function str(value, max)
    if type(value) ~= 'string' then return '' end
    return value:sub(1, max)
end

-- ── Esquema (se crea solo al arrancar, no hay que importar nada) ────────────
MySQL.ready(function()
    MySQL.query.await([[CREATE TABLE IF NOT EXISTS nx_tablet (
        identifier VARCHAR(64) NOT NULL, k VARCHAR(32) NOT NULL, v LONGTEXT NULL,
        PRIMARY KEY (identifier, k))]])
    MySQL.query.await([[CREATE TABLE IF NOT EXISTS nx_tablet_photos (
        id INT NOT NULL AUTO_INCREMENT, identifier VARCHAR(64) NOT NULL, url LONGTEXT NOT NULL,
        created_at BIGINT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY identifier (identifier))]])
    MySQL.query.await([[CREATE TABLE IF NOT EXISTS nx_tablet_bank (
        id INT NOT NULL AUTO_INCREMENT, identifier VARCHAR(64) NOT NULL, label VARCHAR(96) NOT NULL,
        amount BIGINT NOT NULL, created_at BIGINT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY identifier (identifier))]])
    MySQL.query.await([[CREATE TABLE IF NOT EXISTS nx_tablet_playlists (
        id INT NOT NULL AUTO_INCREMENT, identifier VARCHAR(64) NOT NULL, owner_name VARCHAR(64) NOT NULL,
        name VARCHAR(48) NOT NULL, tracks LONGTEXT NULL, shared TINYINT(1) NOT NULL DEFAULT 0,
        PRIMARY KEY (id), KEY identifier (identifier))]])
end)

-- ── Almacén clave/valor por personaje ───────────────────────────────────────
function KVGet(id, key, default)
    local raw = MySQL.scalar.await('SELECT v FROM nx_tablet WHERE identifier = ? AND k = ?', { id, key })
    if not raw then return default end
    local ok, data = pcall(json.decode, raw)
    return ok and data ~= nil and data or default
end

function KVSet(id, key, value)
    MySQL.prepare.await('INSERT INTO nx_tablet (identifier, k, v) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)',
        { id, key, json.encode(value) })
end

-- ── Router ──────────────────────────────────────────────────────────────────
lib.callback.register('nx-tablet:req', function(src, action, payload)
    local route = type(action) == 'string' and Routes[action]
    if not route then return { ok = false, error = 'acción desconocida' } end

    local xPlayer = Bridge.GetPlayer(src)
    if not xPlayer then return { ok = false, error = 'sin personaje' } end

    local ok, result = pcall(route, src, xPlayer, type(payload) == 'table' and payload or {})
    if not ok then
        print(('[nx-tablet] error en %s: %s'):format(action, result))
        return { ok = false, error = 'error interno' }
    end
    return result or { ok = true }
end)

-- ── Item ────────────────────────────────────────────────────────────────────
local function hasItem(xPlayer, item)
    local entry = xPlayer.getInventoryItem(item)
    return entry and (entry.count or 0) > 0
end
HasItem = hasItem

-- El framework puede arrancar después que este recurso: se registra en el siguiente tick
CreateThread(function()
    Bridge.RegisterUsableItem(Config.ItemName, function(src)
        TriggerClientEvent('nx-tablet:open', src)
    end)
end)

-- ── Arranque y ajustes ──────────────────────────────────────────────────────
local function loadSettings(id)
    local saved = KVGet(id, 'settings', {})
    local settings = {}
    for key, default in pairs(Config.Defaults) do
        settings[key] = type(saved[key]) == type(default) and saved[key] or default
    end
    return settings
end

Routes.boot = function(_, xPlayer)
    if Config.RequireItem and not hasItem(xPlayer, Config.ItemName) then
        return { ok = false, error = 'No tienes una tablet' }
    end
    local id = xPlayer.identifier
    return {
        ok = true,
        settings = loadSettings(id),
        alarms = KVGet(id, 'alarms', {}),
        player = { name = xPlayer.getName(), job = xPlayer.getJob().label },
        config = {
            worldClocks = Config.WorldClocks,
            zooms = Config.Camera.Zooms,
            symbol = Config.Bank.Symbol,
            trending = Config.Music.TrendingQuery,
            defaultVolume = Config.Music.DefaultVolume,
        },
    }
end

Routes['settings:save'] = function(_, xPlayer, p)
    local incoming = type(p.settings) == 'table' and p.settings or {}
    local settings = loadSettings(xPlayer.identifier)
    for key, default in pairs(Config.Defaults) do
        local value = incoming[key]
        if type(value) == type(default) then
            if type(value) == 'string' then value = value:sub(1, 2048) end
            if type(value) == 'number' then value = math.max(0, math.min(100, value)) end
            settings[key] = value
        end
    end
    KVSet(xPlayer.identifier, 'settings', settings)
    return { ok = true, settings = settings }
end

Routes['settings:reset'] = function(_, xPlayer)
    KVSet(xPlayer.identifier, 'settings', {})
    return { ok = true, settings = loadSettings(xPlayer.identifier) }
end

-- ── Notas ───────────────────────────────────────────────────────────────────
Routes['notes:list'] = function(_, xPlayer)
    return { ok = true, notes = KVGet(xPlayer.identifier, 'notes', {}) }
end

Routes['notes:save'] = function(_, xPlayer, p)
    local notes = KVGet(xPlayer.identifier, 'notes', {})
    local note = { id = tonumber(p.id) or (now() * 1000 + math.random(0, 999)), title = str(p.title, 80), body = str(p.body, 8000), updated = now() }

    local replaced = false
    for i, n in ipairs(notes) do
        if n.id == note.id then notes[i] = note; replaced = true; break end
    end
    if not replaced then
        if #notes >= 100 then return { ok = false, error = 'Máximo 100 notas' } end
        table.insert(notes, 1, note)
    end

    KVSet(xPlayer.identifier, 'notes', notes)
    return { ok = true, notes = notes, id = note.id }
end

Routes['notes:delete'] = function(_, xPlayer, p)
    local notes = KVGet(xPlayer.identifier, 'notes', {})
    for i, n in ipairs(notes) do
        if n.id == tonumber(p.id) then table.remove(notes, i); break end
    end
    KVSet(xPlayer.identifier, 'notes', notes)
    return { ok = true, notes = notes }
end

-- ── Alarmas (hora del juego) ────────────────────────────────────────────────
Routes['alarms:save'] = function(_, xPlayer, p)
    local alarms = {}
    for _, a in ipairs(type(p.alarms) == 'table' and p.alarms or {}) do
        if #alarms >= 20 then break end
        local h, m = tonumber(a.h), tonumber(a.m)
        if h and m and h >= 0 and h < 24 and m >= 0 and m < 60 then
            alarms[#alarms + 1] = { h = math.floor(h), m = math.floor(m), label = str(a.label, 40), on = a.on == true }
        end
    end
    KVSet(xPlayer.identifier, 'alarms', alarms)
    return { ok = true, alarms = alarms }
end

-- ── Galería ─────────────────────────────────────────────────────────────────
local function maxPhotos()
    return (Config.Camera.UploadUrl ~= '' and Config.Camera.MaxPhotos) or Config.Camera.MaxLocalPhotos
end

-- Las fotos en base64 pesan demasiado para un callback normal: van por evento latente
local function pushGallery(src, identifier)
    local rows = MySQL.query.await('SELECT id, url, created_at FROM nx_tablet_photos WHERE identifier = ? ORDER BY id DESC LIMIT ?',
        { identifier, maxPhotos() })
    TriggerLatentClientEvent('nx-tablet:push', src, 500000, 'gallery', rows or {})
end

local function addPhoto(src, identifier, url)
    local count = MySQL.scalar.await('SELECT COUNT(*) FROM nx_tablet_photos WHERE identifier = ?', { identifier }) or 0
    if count >= maxPhotos() then
        Bridge.NotifyPlayer(src, 'Galería llena: borra alguna foto')
        return false
    end
    MySQL.insert.await('INSERT INTO nx_tablet_photos (identifier, url, created_at) VALUES (?, ?, ?)', { identifier, url, now() })
    TriggerClientEvent('nx-tablet:push', src, 'photo', true)
    return true
end

Routes['gallery:list'] = function(src, xPlayer)
    pushGallery(src, xPlayer.identifier)
    return { ok = true }
end

Routes['gallery:add'] = function(src, xPlayer, p)
    local url = str(p.url, 1024)
    if not url:match('^https://') then return { ok = false, error = 'URL inválida' } end
    return { ok = addPhoto(src, xPlayer.identifier, url) }
end

RegisterNetEvent('nx-tablet:gallery:upload', function(data)
    local src = source
    local xPlayer = Bridge.GetPlayer(src)
    -- ~1.5 MB de base64 como mucho y solo imágenes JPEG/PNG
    if not xPlayer or type(data) ~= 'string' or #data > 1500000 or not data:match('^data:image/[jpegn]+;base64,') then return end
    addPhoto(src, xPlayer.identifier, data)
end)

Routes['gallery:delete'] = function(src, xPlayer, p)
    MySQL.update.await('DELETE FROM nx_tablet_photos WHERE id = ? AND identifier = ?', { tonumber(p.id) or 0, xPlayer.identifier })
    pushGallery(src, xPlayer.identifier)
    return { ok = true }
end

-- ── Banco ───────────────────────────────────────────────────────────────────
local function logTransaction(identifier, label, amount)
    MySQL.insert('INSERT INTO nx_tablet_bank (identifier, label, amount, created_at) VALUES (?, ?, ?, ?)', { identifier, label, amount, now() })
end

local function bankInfo(xPlayer)
    return {
        ok = true,
        cash = xPlayer.getAccount('money').money,
        bank = xPlayer.getAccount('bank').money,
        transactions = MySQL.query.await('SELECT label, amount, created_at FROM nx_tablet_bank WHERE identifier = ? ORDER BY id DESC LIMIT 40',
            { xPlayer.identifier }) or {},
    }
end

Routes['bank:info'] = function(_, xPlayer) return bankInfo(xPlayer) end

Routes['bank:transfer'] = function(src, xPlayer, p)
    local amount = math.floor(tonumber(p.amount) or 0)
    local target = Bridge.GetPlayer(tonumber(p.target) or -1)

    if amount <= 0 or amount > Config.Bank.MaxTransfer then return { ok = false, error = 'Cantidad no válida' } end
    if not target or target.source == src then return { ok = false, error = 'Ese ID no está conectado' } end
    if xPlayer.getAccount('bank').money < amount then return { ok = false, error = 'Saldo insuficiente' } end

    xPlayer.removeAccountMoney('bank', amount)
    target.addAccountMoney('bank', amount)
    logTransaction(xPlayer.identifier, 'Transferencia a ' .. target.getName(), -amount)
    logTransaction(target.identifier, 'Transferencia de ' .. xPlayer.getName(), amount)
    Bridge.NotifyPlayer(target.source,('Has recibido %s%s de %s'):format(Config.Bank.Symbol, amount, xPlayer.getName()))

    return bankInfo(xPlayer)
end

-- ── Perfil ──────────────────────────────────────────────────────────────────
Routes['profile:get'] = function(_, xPlayer)
    local row = Bridge.Profile(xPlayer)
    local job = xPlayer.getJob()
    return {
        ok = true,
        profile = {
            name = xPlayer.getName(),
            dob = row.dob,
            sex = row.sex,
            height = row.height,
            job = job.label,
            grade = job.grade_label,
            cash = xPlayer.getAccount('money').money,
            bank = xPlayer.getAccount('bank').money,
            id = xPlayer.source,
        },
    }
end
