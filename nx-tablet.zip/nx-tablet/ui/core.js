/* ==========================================================================
   NX Tablet -- núcleo de la interfaz
   Pantalla de bloqueo, inicio, centro de control, registro de apps y puente
   con el cliente Lua. Abierto en un navegador normal (sin FiveM) arranca en
   modo demo con datos de prueba para poder maquetar.
   ========================================================================== */

const T = {
    resource: typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'nx-tablet',
    dev: typeof GetParentResourceName !== 'function',
    apps: [],
    current: null,
    events: {},
    state: {
        open: false, locked: true, settings: {}, player: {}, alarms: [],
        config: { worldClocks: [], zooms: [1], symbol: '$', defaultVolume: 0.5 },
        status: { hours: 12, minutes: 0, temp: 22, weather: 'CLEAR', weatherLabel: 'Despejado', wind: 0, street: '' },
        music: null, progress: { time: 0, duration: 0 },
    },
};
window.T = T;

/* ── Eventos internos ─────────────────────────────────────────────────── */
T.on = (name, fn) => { (T.events[name] = T.events[name] || []).push(fn); };
T.emit = (name, data) => (T.events[name] || []).forEach((fn) => { try { fn(data); } catch (e) { console.error(e); } });

/* ── Puente con Lua ───────────────────────────────────────────────────── */
T.post = (name, data) => {
    if (T.dev) return Promise.resolve(T.mock(name, data || {}));
    return fetch(`https://${T.resource}/${name}`, { method: 'POST', body: JSON.stringify(data || {}) })
        .then((r) => r.json()).catch(() => ({ ok: false, error: 'sin respuesta' }));
};
T.req = (action, payload) => T.post('req', { action, payload });
T.client = (action, payload) => T.post('client', { action, payload });

/* ── DOM ──────────────────────────────────────────────────────────────── */
T.el = (tag, props, children) => {
    const el = document.createElement(tag);
    if (Array.isArray(props) || props instanceof Node || typeof props === 'string') { children = props; props = {}; }
    Object.entries(props || {}).forEach(([k, v]) => {
        if (v === null || v === undefined || v === false) return;
        if (k === 'class') el.className = v;
        else if (k === 'html') el.innerHTML = v;
        else if (k === 'text') el.textContent = v;
        else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
        else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
        else if (k === 'value') el.value = v;
        else el.setAttribute(k, v);
    });
    [].concat(children === undefined ? [] : children).forEach((c) => {
        if (c === null || c === undefined || c === false) return;
        el.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
    });
    return el;
};
T.$ = (sel, root) => (root || document).querySelector(sel);
T.clear = (el) => { el.textContent = ''; return el; };

const ICONS = {
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1.08-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1.08 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    cloud: '<path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>',
    calc: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15h.01M8 19h.01M12 19h.01M16 19h.01"/>',
    note: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/>',
    card: '<rect x="1" y="4" width="22" height="16" rx="2"/><path d="M1 10h22"/>',
    user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    x: '<path d="M18 6L6 18M6 6l12 12"/>',
    wifi: '<path d="M5 12.55a11 11 0 0 1 14.08 0M1.42 9a16 16 0 0 1 21.16 0M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/>',
    plane: '<path d="M17.8 19.2L16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"/>',
    eyeoff: '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24M1 1l22 22"/>',
    bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0"/>',
    sun: '<circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>',
    volume: '<path d="M11 5L6 9H2v6h4l5 4V5zM19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/>',
    lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    play: '<path d="M6 3l14 9-14 9V3z" fill="currentColor"/>',
    pause: '<path d="M6 4h4v16H6zM14 4h4v16h-4z" fill="currentColor"/>',
    next: '<path d="M5 4l10 8-10 8V4zM19 5v14"/>',
    prev: '<path d="M19 20L9 12l10-8v16zM5 19V5"/>',
    shuffle: '<path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',
    repeat: '<path d="M17 1l4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3"/>',
    bluetooth: '<path d="M6.5 6.5l11 11L12 23V1l5.5 5.5-11 11"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>',
    left: '<path d="M15 18l-6-6 6-6"/>',
    right: '<path d="M9 18l6-6-6-6"/>',
    zap: '<path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>',
    up: '<path d="M12 19V5M5 12l7-7 7 7"/>',
    globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
    stopwatch: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M9 2h6"/>',
    timer: '<path d="M5 22h14M5 2h14M17 22v-4.17a2 2 0 0 0-.59-1.42L12 12l-4.41 4.41A2 2 0 0 0 7 17.83V22M7 2v4.17a2 2 0 0 0 .59 1.42L12 12l4.41-4.41A2 2 0 0 0 17 6.17V2"/>',
    send: '<path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/>',
    home: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    share: '<path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8M16 6l-4-4-4 4M12 2v13"/>',
    edit: '<path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    signal: '<path d="M2 20h.01M7 20v-4M12 20v-8M17 20V8M22 4v16"/>',
};
T.icon = (name) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[name] || ''}</svg>`;
T.svg = (name, cls) => T.el('span', { class: 'ico ' + (cls || ''), html: T.icon(name), style: { display: 'inline-grid' } });

/* ── Formato ──────────────────────────────────────────────────────────── */
T.pad = (n) => String(n).padStart(2, '0');
T.hhmm = (h, m) => `${T.pad(h)}:${T.pad(m)}`;
T.money = (n) => (Number(n) < 0 ? '-' : '') + (T.state.config.symbol || '$') + Math.abs(Math.floor(Number(n) || 0)).toLocaleString('es-ES');
T.secs = (s) => { s = Math.max(0, Math.floor(s || 0)); return `${Math.floor(s / 60)}:${T.pad(s % 60)}`; };
T.date = (unix) => new Date(unix * 1000).toLocaleString('es-ES', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });

/* ── Fondos y marcos (los usa Ajustes) ────────────────────────────────── */
T.WALLPAPERS = [
    { id: 'aurora', name: 'Aurora', css: 'linear-gradient(160deg,#a8c8ff 0%,#4f6fd8 45%,#a9d4f5 100%)' },
    { id: 'sunset', name: 'Atardecer', css: 'linear-gradient(160deg,#ff9a5a,#ff4f7b 55%,#5b2a86)' },
    { id: 'ocean', name: 'Océano', css: 'linear-gradient(160deg,#0f4c75,#1b8fb5 55%,#64d8cb)' },
    { id: 'night', name: 'Noche', css: 'linear-gradient(160deg,#0b1026,#1d2a5c 60%,#3a2f6b)' },
    { id: 'forest', name: 'Bosque', css: 'linear-gradient(160deg,#0f3d2e,#1e7a55 55%,#9bd770)' },
    { id: 'ruby', name: 'Rubí', css: 'linear-gradient(160deg,#3a0712,#a4133c 55%,#ff4d6d)' },
    { id: 'lavender', name: 'Lavanda', css: 'linear-gradient(160deg,#4b2c83,#8e6bd8 55%,#e1c6ff)' },
    { id: 'sakura', name: 'Sakura', css: 'linear-gradient(160deg,#c2185b,#f06292 55%,#ffd1dc)' },
    { id: 'ice', name: 'Hielo', css: 'linear-gradient(160deg,#dfeffa,#9cc7e6 55%,#5a8fb8)' },
    { id: 'matrix', name: 'Matrix', css: 'linear-gradient(160deg,#000,#022c17 55%,#0a5c2f)' },
    { id: 'graphite', name: 'Grafito', css: 'linear-gradient(160deg,#16181d,#2a2e37 55%,#3c414d)' },
    { id: 'gold', name: 'Oro', css: 'linear-gradient(160deg,#3d2c02,#b8860b 55%,#ffd76a)' },
];
T.FRAMES = [
    { id: 'none', name: 'Ninguno', color: 'transparent' },
    { id: 'white', name: 'Blanco', color: '#e9edf5' },
    { id: 'blue', name: 'Azul', color: '#2f8cff' },
    { id: 'gold', name: 'Oro', color: '#f5b83d' },
    { id: 'green', name: 'Verde', color: '#34c759' },
    { id: 'red', name: 'Rojo', color: '#ff453a' },
    { id: 'pink', name: 'Rosa', color: '#ff2d78' },
    { id: 'rainbow', name: 'Arcoíris', color: 'transparent' },
];

T.applySettings = () => {
    const s = T.state.settings;
    const wp = T.WALLPAPERS.find((w) => w.id === s.wallpaper);
    const url = !wp && /^(https:|data:image)/.test(s.wallpaper || '') ? s.wallpaper : null;
    T.$('#wallpaper').style.background = url ? `center / cover no-repeat url("${url}")` : (wp || T.WALLPAPERS[0]).css;

    const frame = T.FRAMES.find((f) => f.id === s.frame) || T.FRAMES[0];
    document.documentElement.style.setProperty('--frame', frame.color);
    T.$('#device').classList.toggle('frame-rainbow', frame.id === 'rainbow');

    T.$('#dim').style.opacity = String((100 - Math.max(20, s.brightness || 100)) / 100);
    document.body.classList.toggle('streamer', !!s.streamer);
    T.$('#sb-plane').classList.toggle('hidden', !s.airplane);
    T.$('#sb-signal').classList.toggle('hidden', !!s.airplane);
};

let saveTimer = null;
T.saveSettings = (patch) => {
    Object.assign(T.state.settings, patch);
    T.applySettings();
    T.emit('settings', T.state.settings);
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => T.req('settings:save', { settings: T.state.settings }), 400);
};

/* ── Sonidos y avisos ─────────────────────────────────────────────────── */
let audioCtx = null;
T.beep = (freq = 880, ms = 60, force) => {
    const s = T.state.settings;
    if (!force && s.sounds === false) return;
    try {
        audioCtx = audioCtx || new AudioContext();
        const o = audioCtx.createOscillator(); const g = audioCtx.createGain();
        o.frequency.value = freq; g.gain.value = 0.08 * ((s.volume ?? 60) / 100);
        o.connect(g); g.connect(audioCtx.destination); o.start(); o.stop(audioCtx.currentTime + ms / 1000);
    } catch (e) { /* sin audio */ }
};

let toastTimer = null;
T.toast = (text, kind) => {
    const el = T.$('#toast');
    el.textContent = text;
    el.className = 'toast show ' + (kind || '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.className = 'toast'; }, 2200);
};

// Aviso fuera de la tablet (ESX) cuando está cerrada; dentro, toast
T.notify = (text) => {
    if (T.state.settings.notifications === false || T.state.settings.airplane) return;
    T.beep(660, 180, true);
    if (T.state.open) T.toast(text); else T.post('notify', { text });
};

/* ── Apps ─────────────────────────────────────────────────────────────── */
// def = { id, name, icon, color, dock, render(root), onClose() }
T.app = (def) => { T.apps.push(def); };
// Todas las apps se pintan en el mismo #app: solo redibuja la que está delante
T.showing = (id) => !!(T.current && T.current.id === id);

T.openApp = (id) => {
    const app = T.apps.find((a) => a.id === id);
    if (!app) return;
    if (T.current && T.current.onClose) T.current.onClose();
    T.current = app;
    T.beep(1200, 25);
    T.$('#home').classList.add('hidden');
    const root = T.clear(T.$('#app'));
    root.className = 'layer app-' + id;
    root.removeAttribute('style');
    T.$('#screen').classList.add('in-app');
    app.render(root);
};

T.goHome = () => {
    if (T.current && T.current.onClose) T.current.onClose();
    T.current = null;
    T.$('#app').classList.add('hidden');
    T.$('#screen').classList.remove('in-app');
    if (!T.state.locked) T.$('#home').classList.remove('hidden');
};

/* ── Bloqueo ──────────────────────────────────────────────────────────── */
function renderLock() {
    const st = T.state.status;
    const m = T.state.music;
    T.clear(T.$('#lock')).append(...[
        T.el('div', { class: 'lock-time', text: T.hhmm(st.hours, st.minutes) }),
        T.el('div', { class: 'lock-date', text: new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' }) }),
        m && m.track ? T.el('div', { class: 'lock-np' }, [T.el('img', { src: m.track.thumb }), T.el('div', [T.el('b', m.track.title), T.el('div', { class: 'small', text: m.paused ? 'En pausa' : 'Reproduciendo' })])]) : null,
        T.el('div', { class: 'lock-bottom' }, [
            T.el('div', { class: 'lock-hint', text: 'Desliza hacia arriba para desbloquear' }),
            T.el('div', { class: 'lock-row' }, [
                T.el('button', { class: 'lock-btn', html: T.icon('zap'), onclick: () => T.toast('Linterna no disponible') }),
                handle(),
                T.el('button', { class: 'lock-btn', html: T.icon('camera'), onclick: () => { T.unlock(); T.openApp('camera'); } }),
            ]),
        ]),
    ].filter(Boolean));
}

function handle() {
    const el = T.el('div', { class: 'lock-handle' }, T.el('span', { html: T.icon('up') }));
    let startY = null;
    el.addEventListener('pointerdown', (e) => { startY = e.clientY; el.setPointerCapture(e.pointerId); });
    el.addEventListener('pointermove', (e) => {
        if (startY === null) return;
        const dy = Math.min(0, e.clientY - startY);
        T.$('#lock').style.transform = `translateY(${dy}px)`;
    });
    el.addEventListener('pointerup', (e) => {
        const dy = startY === null ? 0 : e.clientY - startY;
        startY = null;
        T.$('#lock').style.transform = '';
        if (dy < -60 || Math.abs(dy) < 4) T.unlock();
    });
    return el;
}

T.unlock = () => {
    if (!T.state.locked) return;
    T.state.locked = false;
    T.beep(990, 40);
    const lock = T.$('#lock');
    lock.classList.add('leaving');
    setTimeout(() => { lock.classList.add('hidden'); lock.classList.remove('leaving'); }, 330);
    T.$('#home').classList.remove('hidden');
};

T.lock = () => {
    T.closeCC();
    T.goHome();
    T.state.locked = true;
    T.$('#home').classList.add('hidden');
    T.$('#lock').classList.remove('hidden');
    renderLock();
};

/* ── Inicio ───────────────────────────────────────────────────────────── */
function appIcon(app) {
    return T.el('button', { class: 'app-icon', onclick: () => T.openApp(app.id) }, [
        T.el('div', { class: 'app-tile', html: T.icon(app.icon), style: { background: app.color } }),
        T.el('span', app.name),
    ]);
}

function renderHome() {
    const home = T.clear(T.$('#home'));
    home.append(
        T.el('div', { class: 'home-grid' }, T.apps.map(appIcon)),
        T.el('div', { class: 'dock' }, T.apps.filter((a) => a.dock).map(appIcon)),
    );
}

/* ── Centro de control ────────────────────────────────────────────────── */
function slider(icon, value, onChange) {
    const fill = T.el('div', { class: 'fill', style: { height: value + '%' } });
    const el = T.el('div', { class: 'cc-slider' }, [fill, T.el('span', { html: T.icon(icon) })]);
    const set = (e) => {
        const r = el.getBoundingClientRect();
        const v = Math.round(Math.max(0, Math.min(1, (r.bottom - e.clientY) / r.height)) * 100);
        fill.style.height = v + '%';
        onChange(v);
    };
    el.addEventListener('pointerdown', (e) => { el.setPointerCapture(e.pointerId); set(e); el.onpointermove = set; });
    el.addEventListener('pointerup', () => { el.onpointermove = null; });
    return el;
}

T.openCC = () => {
    const s = T.state.settings;
    const cc = T.clear(T.$('#cc'));
    const toggle = (key, icon, extra) => T.el('button', {
        class: 'cc-tile ' + (s[key] ? 'on ' : '') + (extra || ''), html: T.icon(icon),
        onclick: () => { T.saveSettings({ [key]: !s[key] }); T.toast(`${toggleNames[key]} ${s[key] ? 'activado' : 'desactivado'}`); T.openCC(); },
    });
    const m = T.state.music;
    cc.append(T.el('div', { class: 'cc-grid', onclick: (e) => e.stopPropagation() }, [
        toggle('airplane', 'plane', 'orange'),
        toggle('streamer', 'eyeoff'),
        toggle('notifications', 'bell'),
        T.el('button', { class: 'cc-tile', html: T.icon('lock'), onclick: () => T.lock() }),
        T.el('div', { class: 'cc-tile cc-wide' }, m && m.track
            ? [T.el('b', { text: m.track.title, style: { whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } }),
                T.el('div', { class: 'row' }, [
                    T.el('button', { html: T.icon(m.paused ? 'play' : 'pause'), style: { width: '22px' }, onclick: () => T.req(m.paused ? 'music:resume' : 'music:pause') }),
                    T.el('span', { class: 'muted', text: m.paused ? 'En pausa' : 'Reproduciendo' }),
                ])]
            : [T.el('span', { class: 'muted', text: 'Nada sonando' })]),
        slider('sun', s.brightness ?? 100, (v) => T.saveSettings({ brightness: Math.max(20, v) })),
        slider('volume', Math.round((m ? m.volume : T.state.config.defaultVolume) * 100), (v) => { if (T.state.music) T.req('music:volume', { volume: v / 100 }); }),
    ]));
    cc.classList.remove('hidden');
};
const toggleNames = { airplane: 'Modo avión', streamer: 'Modo streamer', notifications: 'Notificaciones' };
T.closeCC = () => T.$('#cc').classList.add('hidden');

/* ── Barra de estado y mini reproductor ───────────────────────────────── */
function renderStatus() {
    const st = T.state.status;
    T.$('#sb-time').textContent = T.hhmm(st.hours, st.minutes);
    T.$('#sb-weather').textContent = `${st.temp}° ${st.weatherLabel}`;
    if (T.state.open && T.state.locked) T.$('.lock-time') && (T.$('.lock-time').textContent = T.hhmm(st.hours, st.minutes));
}

function renderMini() {
    const mini = T.$('#mini');
    const m = T.state.music;
    if (!m || !m.track || T.state.open) { mini.classList.add('hidden'); return; }
    const p = T.state.progress;
    T.clear(mini).append(
        T.el('div', { class: 'np', text: m.paused ? 'EN PAUSA' : 'SONANDO AHORA' }),
        T.el('div', { class: 'row', style: { marginTop: '6px' } }, [
            T.el('img', { src: m.track.thumb }),
            T.el('div', { style: { minWidth: 0 } }, [
                T.el('b', { text: m.track.title, style: { display: 'block', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } }),
                T.el('span', { class: 'muted', text: outputName(m.target) }),
            ]),
        ]),
        T.el('div', { class: 'bar' }, T.el('i', { style: { width: (p.duration > 0 ? (p.time / p.duration) * 100 : 0) + '%' } })),
    );
    mini.classList.remove('hidden');
}
T.outputName = outputName;
function outputName(target) {
    return { ped: 'Altavoz de la tablet', veh: 'Radio del vehículo', obj: 'Boombox' }[target && target.kind] || '';
}

/* ── Cámara (overlay mientras el cliente controla la cámara del juego) ── */
function renderCamera(msg) {
    const cam = T.$('#camui');
    if (!msg.on) {
        cam.classList.add('hidden');
        T.$('#device').classList.remove('hidden');
        if (T.current && T.current.id === 'camera') T.goHome();
        return;
    }
    T.$('#device').classList.add('hidden');
    cam.classList.remove('hidden');
    cam.classList.toggle('hide-ui', !!msg.hidden);
    T.clear(cam).append(
        T.el('div', { class: 'cam-corners' }, [T.el('i'), T.el('i'), T.el('i'), T.el('i')]),
        T.el('div', { class: 'cam-top', text: msg.selfie ? 'Cámara frontal · selfie' : 'Cámara trasera' }),
        T.el('div', { class: 'cam-zoom' }, (msg.selfie ? [] : T.state.config.zooms).map((z) => T.el('span', { class: z === msg.zoom ? 'on' : '', text: z + 'x' }))),
        T.el('div', { class: 'cam-hint' }, [
            T.el('span', [T.el('b', 'CLIC'), 'Foto']), T.el('span', [T.el('b', 'RUEDA'), 'Zoom']),
            T.el('span', [T.el('b', 'E'), 'Girar']), T.el('span', [T.el('b', 'RETROCESO'), 'Salir']),
        ]),
        T.el('div', { class: 'cam-flash' + (msg.flash ? ' go' : '') }),
    );
    if (msg.flash) T.beep(1500, 40, true);
}

/* ── Abrir / cerrar ───────────────────────────────────────────────────── */
T.open = (boot) => {
    T.state.open = true;
    T.state.settings = boot.settings || {};
    T.state.player = boot.player || {};
    T.state.config = Object.assign(T.state.config, boot.config || {});
    T.state.alarms = boot.alarms || T.state.alarms;
    T.applySettings();
    renderStatus();
    renderHome();
    T.lock();
    T.$('#device').classList.remove('hidden');
    renderMini();
};

T.close = () => {
    T.state.open = false;
    T.closeCC();
    T.goHome();
    T.$('#device').classList.add('hidden');
    renderMini();
};

T.exit = () => T.post('close');

/* ── Mensajes del cliente ─────────────────────────────────────────────── */
let lastMinute = -1;
window.addEventListener('message', (e) => {
    const msg = e.data || {};
    switch (msg.action) {
        case 'open': T.open(msg.boot); break;
        case 'close': T.close(); break;
        case 'status':
            T.state.status = msg.status;
            renderStatus();
            if (msg.status.minutes !== lastMinute) { lastMinute = msg.status.minutes; T.emit('minute', msg.status); }
            T.emit('status', msg.status);
            break;
        case 'camera': renderCamera(msg); break;
        case 'push': T.emit('push:' + msg.event, msg.payload); break;
        case 'music:state':
            T.state.music = msg.state || null;
            if (!msg.state) T.state.progress = { time: 0, duration: 0 };
            T.emit('music', T.state.music);
            renderMini();
            break;
        case 'music:progress':
            T.state.progress = { time: msg.time, duration: msg.duration };
            T.emit('progress', T.state.progress);
            renderMini();
            break;
        case 'music:ended': T.emit('ended'); break;
        default: break;
    }
});

document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !T.state.open) return;
    if (!T.$('#cc').classList.contains('hidden')) T.closeCC();
    else T.exit();
});

T.ready = () => {
    T.$('#sb-close').innerHTML = T.icon('x');
    T.$('#sb-signal').innerHTML = T.icon('wifi');
    T.$('#sb-plane').innerHTML = T.icon('plane');
    T.$('#sb-close').addEventListener('click', (e) => { e.stopPropagation(); T.exit(); });
    T.$('#sb-right').addEventListener('click', () => { if (!T.state.locked) T.openCC(); });
    T.$('#cc').addEventListener('click', T.closeCC);
    T.$('#homebar').addEventListener('click', () => { T.closeCC(); if (!T.state.locked) T.goHome(); });

    if (T.dev) {
        document.body.style.background = 'linear-gradient(#3b4a3f,#1d2620)';
        T.open(T.mock('req', { action: 'boot' }));
    }
};

/* ── Modo demo (navegador sin FiveM) ──────────────────────────────────── */
T.mock = (name, data) => {
    if (name === 'close') { T.close(); setTimeout(() => T.open(T.mock('req', { action: 'boot' })), 800); return { ok: true }; }
    if (name === 'client') {
        if (data.action === 'music:devices') return { ok: true, devices: [{ kind: 'ped', label: 'Altavoz de la tablet', sub: 'Integrado' }, { kind: 'obj', net: 4, label: 'Boombox', sub: 'Altavoz Bluetooth' }], current: { kind: 'ped' } };
        if (data.action === 'camera') { renderCamera({ on: true, zoom: 1 }); setTimeout(() => renderCamera({ on: false }), 2500); }
        return { ok: true };
    }
    if (name !== 'req') return { ok: true };
    const p = data.payload || {};
    const demoTrack = (i) => ({ id: 'dQw4w9WgXc' + i, title: ['Night Drive', 'Los Santos Sunset', 'Vinewood Lights', 'Grove Street Beat', 'Del Perro Waves', 'Mirror Park'][i % 6] + ' (Official Video)', author: 'NX Records', thumb: `https://picsum.photos/seed/nx${i}/320/180`, duration: `${2 + (i % 3)}:${T.pad((i * 17) % 60)}` });
    switch (data.action) {
        case 'boot': return { ok: true, settings: { wallpaper: 'aurora', frame: 'rainbow', brightness: 100, volume: 60, sounds: true, notifications: true, airplane: false, streamer: false }, alarms: [{ h: 7, m: 30, label: 'Trabajo', on: true }], player: { name: 'Rio Testx', job: 'Policía' }, config: { worldClocks: [{ city: 'Madrid', tz: 'Europe/Madrid' }, { city: 'Tokio', tz: 'Asia/Tokyo' }], zooms: [0.5, 1, 2, 3], symbol: '$', trending: 'top hits', defaultVolume: 0.5 } };
        case 'notes:list': return { ok: true, notes: [{ id: 1, title: 'Lista de la compra', body: 'Pan\nLeche\nGasolina', updated: Date.now() / 1000 }] };
        case 'bank:info': case 'bank:transfer': return { ok: true, cash: 18899, bank: 187794, transactions: [{ label: 'Transferencia a Koko', amount: -4000, created_at: Date.now() / 1000 - 3600 }, { label: 'Nómina', amount: 2995, created_at: Date.now() / 1000 - 7200 }] };
        case 'profile:get': return { ok: true, profile: { name: 'Rio Testx', dob: '19/09/1999', sex: 'm', height: 180, job: 'Policía', grade: 'Jefe de departamento', cash: 18899, bank: 187794, id: 3 } };
        case 'playlists:list': case 'playlists:create': case 'playlists:add': return { ok: true, playlists: [{ id: 1, name: 'AWS-RIO', owner_name: 'Rio Testx', mine: true, shared: true, tracks: [demoTrack(1), demoTrack(2)] }, { id: 2, name: 'Chill', owner_name: 'Koko', mine: false, shared: true, tracks: [demoTrack(3)] }] };
        case 'music:search': return { ok: true, results: Array.from({ length: 14 }, (_, i) => demoTrack(i)) };
        case 'music:play':
            setTimeout(() => window.postMessage({ action: 'music:state', state: { track: p.track, volume: 0.5, paused: false, target: { kind: 'ped' } } }), 50);
            return { ok: true };
        case 'gallery:list':
            setTimeout(() => T.emit('push:gallery', Array.from({ length: 7 }, (_, i) => ({ id: i + 1, url: `https://picsum.photos/seed/g${i}/640/400`, created_at: Date.now() / 1000 - i * 5000 }))), 50);
            return { ok: true };
        default: return { ok: true };
    }
};
