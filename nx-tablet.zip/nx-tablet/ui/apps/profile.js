/* Perfil: datos del personaje (tabla users de ESX) */
T.app({
    id: 'profile', name: 'Perfil', icon: 'user', color: 'linear-gradient(160deg,#30d158,#0a8f3a)',
    render(el) {
        const body = T.el('div', { class: 'app-body' }, T.el('div', { class: 'empty grow', text: 'Cargando…' }));
        el.append(T.el('div', { class: 'app-title', text: 'Perfil' }), body);

        T.req('profile:get').then((r) => {
            if (!T.showing('profile') || !r.ok) return;
            const p = r.profile;
            const field = (label, value) => T.el('div', { class: 'prof-field' }, [T.el('div', { class: 'small muted', text: label }), T.el('b', { class: 'sensitive', text: value || '—' })]);
            T.clear(body).append(T.el('div', { class: 'grow scroll pad' }, [
                T.el('div', { class: 'card pad row' }, [
                    T.el('div', { class: 'avatar big', text: (p.name || '?')[0] }),
                    T.el('div', [T.el('div', { class: 'h2 sensitive', text: p.name }), T.el('div', { class: 'muted', text: `${p.job} · ${p.grade || ''}` })]),
                ]),
                T.el('div', { class: 'card pad prof-grid' }, [
                    field('NOMBRE', p.name), field('FECHA DE NACIMIENTO', p.dob),
                    field('SEXO', { m: 'Hombre', f: 'Mujer' }[p.sex] || p.sex), field('ALTURA', p.height ? `${p.height} cm` : null),
                    field('TRABAJO', p.job), field('RANGO', p.grade),
                    field('EFECTIVO', T.money(p.cash)), field('BANCO', T.money(p.bank)),
                    field('ID EN EL SERVIDOR', String(p.id)),
                ]),
                T.el('div', { class: 'row' }, [
                    T.el('button', { class: 'btn grow', text: 'Banco', onclick: () => T.openApp('bank') }),
                    T.el('button', { class: 'btn grow', text: 'Ajustes', onclick: () => T.openApp('settings') }),
                ]),
            ]));
        });
    },
});
