/* Reloj: mundial, alarmas (hora del juego), cronómetro y temporizador.
   El cronómetro y el temporizador siguen corriendo con la app cerrada. */
(() => {
    let tab = 'world';
    let root = null;
    let tick = null;

    const sw = { start: 0, acc: 0, running: false, laps: [] };
    const tm = { total: 300, left: 300, end: 0, running: false };

    const swNow = () => sw.acc + (sw.running ? Date.now() - sw.start : 0);
    const fmtMs = (ms) => `${T.pad(Math.floor(ms / 60000))}:${T.pad(Math.floor(ms / 1000) % 60)},${T.pad(Math.floor(ms / 10) % 100)}`;
    const fmtS = (s) => `${Math.floor(s / 3600)}:${T.pad(Math.floor(s / 60) % 60)}:${T.pad(Math.floor(s) % 60)}`;
    const tmLeft = () => (tm.running ? Math.max(0, (tm.end - Date.now()) / 1000) : tm.left);

    // Temporizador: aviso aunque la tablet esté cerrada
    setInterval(() => {
        if (tm.running && tmLeft() <= 0) { tm.running = false; tm.left = tm.total; T.notify('⏰ El temporizador ha terminado'); draw(); }
    }, 500);

    // Alarmas: comprobación al cambiar el minuto del juego
    T.on('minute', (st) => {
        (T.state.alarms || []).forEach((a) => { if (a.on && a.h === st.hours && a.m === st.minutes) T.notify(`⏰ Alarma ${T.hhmm(a.h, a.m)} ${a.label || ''}`); });
    });

    const saveAlarms = () => T.req('alarms:save', { alarms: T.state.alarms }).then((r) => { if (r.ok && r.alarms) T.state.alarms = r.alarms; draw(); });

    const VIEWS = {
        world() {
            const st = T.state.status;
            const zones = T.state.config.worldClocks || [];
            return [T.el('div', { class: 'h1 pad', text: 'Reloj mundial' }), T.el('div', { class: 'pad clk-list' }, [
                T.el('div', { class: 'card clk-row' }, [T.el('div', [T.el('b', 'Los Santos'), T.el('div', { class: 'small', style: { color: 'var(--accent)' }, text: 'Hora del juego' })]), T.el('div', { class: 'clk-big', text: T.hhmm(st.hours, st.minutes) })]),
                ...zones.map((z) => T.el('div', { class: 'card clk-row' }, [
                    T.el('b', z.city),
                    T.el('div', { class: 'clk-big', text: new Date().toLocaleTimeString('es-ES', { timeZone: z.tz, hour: '2-digit', minute: '2-digit' }) }),
                ])),
            ])];
        },
        alarm() {
            const h = T.el('input', { type: 'number', min: 0, max: 23, value: 8, style: { width: '70px' } });
            const m = T.el('input', { type: 'number', min: 0, max: 59, value: 0, style: { width: '70px' } });
            const label = T.el('input', { placeholder: 'Etiqueta', class: 'grow' });
            return [T.el('div', { class: 'h1 pad', text: 'Alarmas' }), T.el('div', { class: 'pad clk-list' }, [
                T.el('div', { class: 'card row pad' }, [h, ':', m, label, T.el('button', {
                    class: 'btn primary', text: 'Añadir',
                    onclick: () => { T.state.alarms.push({ h: Number(h.value) % 24, m: Number(m.value) % 60, label: label.value, on: true }); saveAlarms(); },
                })]),
                T.el('div', { class: 'small muted', text: 'Las alarmas suenan con la hora del juego (Los Santos).' }),
                ...(T.state.alarms.length ? T.state.alarms.map((a, i) => T.el('div', { class: 'card clk-row' }, [
                    T.el('div', [T.el('div', { class: 'clk-big', text: T.hhmm(a.h, a.m) }), T.el('div', { class: 'small muted', text: a.label || 'Alarma' })]),
                    T.el('div', { class: 'row' }, [
                        T.el('button', { class: 'switch' + (a.on ? ' on' : ''), onclick: () => { a.on = !a.on; saveAlarms(); } }),
                        T.el('button', { class: 'btn danger', html: T.icon('trash'), style: { width: '40px' }, onclick: () => { T.state.alarms.splice(i, 1); saveAlarms(); } }),
                    ]),
                ])) : [T.el('div', { class: 'empty', text: 'Sin alarmas' })]),
            ])];
        },
        stopwatch() {
            return [T.el('div', { class: 'h1 pad', text: 'Cronómetro' }), T.el('div', { class: 'clk-center' }, [
                T.el('div', { class: 'clk-huge', id: 'sw-time', text: fmtMs(swNow()) }),
                T.el('div', { class: 'row', style: { gap: '30px' } }, [
                    T.el('button', { class: 'clk-btn', text: sw.running ? 'Vuelta' : 'Reiniciar', onclick: () => { if (sw.running) sw.laps.unshift(swNow()); else { sw.acc = 0; sw.laps = []; } draw(); } }),
                    T.el('button', { class: 'clk-btn ' + (sw.running ? 'red' : 'green'), text: sw.running ? 'Parar' : 'Iniciar', onclick: () => { if (sw.running) { sw.acc = swNow(); sw.running = false; } else { sw.start = Date.now(); sw.running = true; } draw(); } }),
                ]),
                T.el('div', { class: 'clk-laps scroll' }, sw.laps.map((l, i) => T.el('div', { class: 'row between' }, [T.el('span', `Vuelta ${sw.laps.length - i}`), T.el('span', fmtMs(l))]))),
            ])];
        },
        timer() {
            const mins = T.el('input', { type: 'number', min: 1, max: 600, value: Math.round(tm.total / 60), style: { width: '90px' } });
            const idle = !tm.running && tm.left === tm.total;
            return [T.el('div', { class: 'h1 pad', text: 'Temporizador' }), T.el('div', { class: 'clk-center' }, [
                T.el('div', { class: 'clk-huge', id: 'tm-time', text: fmtS(tmLeft()) }),
                idle ? T.el('div', { class: 'row' }, [mins, T.el('span', { class: 'muted', text: 'minutos' })]) : null,
                T.el('div', { class: 'row', style: { gap: '30px' } }, [
                    T.el('button', { class: 'clk-btn', text: 'Cancelar', onclick: () => { tm.running = false; tm.left = tm.total; draw(); } }),
                    T.el('button', {
                        class: 'clk-btn ' + (tm.running ? 'orange' : 'green'), text: tm.running ? 'Pausa' : (idle ? 'Iniciar' : 'Reanudar'),
                        onclick: () => {
                            if (tm.running) { tm.left = tmLeft(); tm.running = false; } else {
                                if (idle) { tm.total = Math.max(1, Number(mins.value) || 5) * 60; tm.left = tm.total; }
                                tm.end = Date.now() + tm.left * 1000; tm.running = true;
                            }
                            draw();
                        },
                    }),
                ]),
            ])];
        },
    };

    const TABS = [['world', 'Mundial', 'globe'], ['alarm', 'Alarmas', 'bell'], ['stopwatch', 'Cronómetro', 'stopwatch'], ['timer', 'Temporizador', 'timer']];

    function draw() {
        if (!T.showing('clock')) return;
        T.clear(root).append(
            T.el('div', { class: 'grow scroll clk' }, VIEWS[tab]()),
            T.el('div', { class: 'tabs' }, TABS.map(([id, name, icon]) => T.el('button', { class: id === tab ? 'on' : '', onclick: () => { tab = id; draw(); } }, [T.el('span', { html: T.icon(icon) }), name]))),
        );
    }

    T.app({
        id: 'clock', name: 'Reloj', icon: 'clock', color: 'linear-gradient(160deg,#1c1c1e,#000)',
        render(el) {
            root = el;
            el.style.background = '#000';
            draw();
            tick = setInterval(() => {
                const a = T.$('#sw-time', root); if (a) a.textContent = fmtMs(swNow());
                const b = T.$('#tm-time', root); if (b) b.textContent = fmtS(tmLeft());
            }, 50);
        },
        onClose() { clearInterval(tick); },
    });
    T.on('minute', () => { if (tab === 'world') draw(); });
})();
