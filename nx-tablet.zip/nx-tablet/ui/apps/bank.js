/* Banco: saldos de ESX, transferencias por ID y movimientos */
(() => {
    let data = null;

    function draw() {
        if (!T.showing('bank')) return;
        const body = T.clear(T.$('.app-body', T.$('#app')));
        if (!data) { body.append(T.el('div', { class: 'empty grow', text: 'Cargando…' })); return; }

        const target = T.el('input', { type: 'number', placeholder: 'ID del jugador', min: 1 });
        const amount = T.el('input', { type: 'number', placeholder: 'Cantidad', min: 1 });
        const send = T.el('button', {
            class: 'btn primary', html: T.icon('send'), title: 'Enviar', style: { width: '46px' },
            onclick: () => {
                send.disabled = true;
                T.req('bank:transfer', { target: Number(target.value), amount: Number(amount.value) }).then((r) => {
                    send.disabled = false;
                    if (!r.ok) { T.toast(r.error || 'Error', 'err'); return; }
                    data = r; T.toast('Transferencia enviada', 'ok'); draw();
                });
            },
        });

        body.append(T.el('div', { class: 'grow scroll pad bank' }, [
            T.el('div', { class: 'bank-hero' }, [
                T.el('div', { class: 'small', text: 'SALDO TOTAL' }),
                T.el('div', { class: 'bank-total sensitive', text: T.money(data.bank + data.cash) }),
            ]),
            T.el('div', { class: 'bank-cols' }, [
                T.el('div', { class: 'card pad' }, [
                    T.el('div', { class: 'small muted', text: 'CUENTAS' }),
                    T.el('div', { class: 'bank-acc' }, [T.el('span', { class: 'set-ico', html: T.icon('card'), style: { background: '#5e5ce6' } }), T.el('div', { class: 'grow' }, [T.el('b', 'Banco'), T.el('div', { class: 'small muted', text: 'Cuenta corriente' })]), T.el('b', { class: 'sensitive', text: T.money(data.bank) })]),
                    T.el('div', { class: 'bank-acc' }, [T.el('span', { class: 'set-ico', html: T.icon('card'), style: { background: '#34c759' } }), T.el('div', { class: 'grow' }, [T.el('b', 'Efectivo'), T.el('div', { class: 'small muted', text: 'En tu cartera' })]), T.el('b', { class: 'sensitive', text: T.money(data.cash) })]),
                    T.el('div', { class: 'small muted', text: 'TRANSFERIR', style: { marginTop: '16px' } }),
                    T.el('div', { class: 'row', style: { marginTop: '8px' } }, [target, amount, send]),
                ]),
                T.el('div', { class: 'card pad' }, [
                    T.el('div', { class: 'small muted', text: 'MOVIMIENTOS' }),
                    ...(data.transactions.length ? data.transactions.map((t) => T.el('div', { class: 'bank-tx' }, [
                        T.el('div', [T.el('b', t.label), T.el('div', { class: 'small muted', text: T.date(t.created_at) })]),
                        T.el('b', { class: 'sensitive', text: (t.amount > 0 ? '+' : '') + T.money(t.amount), style: { color: t.amount > 0 ? 'var(--green)' : 'var(--red)' } }),
                    ])) : [T.el('div', { class: 'empty', text: 'Sin movimientos' })]),
                ]),
            ]),
        ]));
    }

    T.app({
        id: 'bank', name: 'Banco', icon: 'card', color: 'linear-gradient(160deg,#7b61ff,#4a2fd1)',
        render(el) {
            el.append(T.el('div', { class: 'app-title', text: 'Banco' }), T.el('div', { class: 'app-body' }));
            draw();
            T.req('bank:info').then((r) => { if (r.ok) { data = r; draw(); } });
        },
    });
})();
