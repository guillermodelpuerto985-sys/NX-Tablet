/* Tiempo: clima y hora del juego */
(() => {
    let root = null;
    const SKY = {
        EXTRASUNNY: 'linear-gradient(160deg,#4fa3ff,#9fd3ff)', CLEAR: 'linear-gradient(160deg,#4f8fe0,#a3cdf5)',
        CLOUDS: 'linear-gradient(160deg,#6d8099,#b9c6d6)', OVERCAST: 'linear-gradient(160deg,#5c6675,#9aa4b2)',
        RAIN: 'linear-gradient(160deg,#2c3e50,#5d6d7e)', THUNDER: 'linear-gradient(160deg,#1a1f2b,#434c5e)',
        SMOG: 'linear-gradient(160deg,#8a8f98,#c9cdd3)', FOGGY: 'linear-gradient(160deg,#9aa3ad,#d5d9de)',
        SNOW: 'linear-gradient(160deg,#c7d6e6,#f2f6fa)', BLIZZARD: 'linear-gradient(160deg,#aab8c8,#e6ecf2)',
    };

    function draw() {
        if (!T.showing('weather')) return;
        const st = T.state.status;
        const tile = (label, value) => T.el('div', { class: 'wx-tile' }, [T.el('div', { class: 'small', text: label }), T.el('b', value)]);
        T.clear(root).append(T.el('div', { class: 'wx', style: { background: SKY[st.weather] || SKY.CLEAR } }, [
            T.el('div', { class: 'wx-head' }, [T.el('div', { class: 'h1', text: 'Los Santos' }), T.el('div', { text: st.street || 'San Andreas' })]),
            T.el('div', { class: 'wx-main' }, [
                T.el('div', { class: 'small', text: 'HORA DEL JUEGO' }),
                T.el('div', { class: 'wx-time', text: T.hhmm(st.hours, st.minutes) }),
                T.el('b', { text: st.weatherLabel, style: { fontSize: '20px' } }),
                T.el('div', { class: 'wx-temp', text: `${st.temp}°` }),
            ]),
            T.el('div', { class: 'wx-tiles' }, [
                tile('CIELO', st.weatherLabel), tile('VIENTO', `${st.wind} km/h`),
                tile('SENSACIÓN', `${st.temp + (st.wind > 20 ? -2 : 1)}°`), tile('MÁX / MÍN', `${st.temp + 3}° / ${st.temp - 4}°`),
            ]),
        ]));
    }

    T.on('minute', draw);
    T.app({ id: 'weather', name: 'Tiempo', icon: 'cloud', color: 'linear-gradient(160deg,#5ac8fa,#007aff)', render(el) { root = el; draw(); } });
})();
