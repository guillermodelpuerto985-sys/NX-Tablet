/* Notas */
(() => {
    let notes = [];
    let selected = null;
    let root = null;

    const save = (title, body) => T.req('notes:save', { id: selected, title, body }).then((r) => {
        if (!r.ok) { T.toast(r.error || 'No se pudo guardar', 'err'); return; }
        notes = r.notes; selected = r.id; T.toast('Nota guardada', 'ok'); draw();
    });

    function draw() {
        if (!T.showing('notes')) return;
        const note = notes.find((n) => n.id === selected) || { title: '', body: '' };
        const title = T.el('input', { class: 'notes-title', placeholder: 'Título', value: note.title });
        const body = T.el('textarea', { class: 'notes-body grow', placeholder: 'Escribe algo…', value: note.body });

        T.clear(T.$('.app-body', root)).append(
            T.el('div', { class: 'notes-side scroll' }, [
                T.el('div', { class: 'row between pad' }, [T.el('div', { class: 'h2', text: 'Notas' }), T.el('button', { class: 'btn primary', html: T.icon('plus'), style: { width: '38px', padding: '7px' }, onclick: () => { selected = null; draw(); } })]),
                ...(notes.length ? notes.map((n) => T.el('button', { class: 'notes-item' + (n.id === selected ? ' on' : ''), onclick: () => { selected = n.id; draw(); } }, [
                    T.el('b', n.title || 'Sin título'), T.el('div', { class: 'small muted', text: (n.body || '').split('\n')[0].slice(0, 40) || '—' }),
                ])) : [T.el('div', { class: 'empty', text: 'Sin notas' })]),
            ]),
            T.el('div', { class: 'notes-main' }, [
                title, body,
                T.el('div', { class: 'row', style: { justifyContent: 'flex-end' } }, [
                    selected ? T.el('button', { class: 'btn danger', text: 'Eliminar', onclick: () => T.req('notes:delete', { id: selected }).then((r) => { notes = r.notes || []; selected = null; draw(); }) }) : null,
                    T.el('button', { class: 'btn primary', text: 'Guardar', onclick: () => save(title.value, body.value) }),
                ]),
            ]),
        );
    }

    T.app({
        id: 'notes', name: 'Notas', icon: 'note', color: 'linear-gradient(160deg,#ffd60a,#ffb300)',
        render(el) {
            root = el;
            el.append(T.el('div', { class: 'app-title', text: 'Notas' }), T.el('div', { class: 'app-body' }));
            draw();
            T.req('notes:list').then((r) => { notes = r.notes || []; draw(); });
        },
    });
})();
