/* Galería: fotos de la cámara, visor, borrar y poner de fondo */
(() => {
    let photos = null;
    let root = null;
    let viewing = null; // índice abierto en el visor

    function draw() {
        if (!T.showing('gallery')) return;
        const body = T.clear(T.$('.app-body', root));

        if (photos === null) { body.append(T.el('div', { class: 'empty grow', text: 'Cargando…' })); return; }
        if (!photos.length) { body.append(T.el('div', { class: 'empty grow', text: 'Aún no hay fotos. Hazlas con la app Cámara.' })); return; }

        if (viewing !== null && photos[viewing]) {
            const p = photos[viewing];
            const go = (d) => { viewing = (viewing + d + photos.length) % photos.length; draw(); };
            body.append(T.el('div', { class: 'viewer' }, [
                T.el('div', { class: 'row between pad' }, [
                    T.el('button', { class: 'btn', html: T.icon('left'), onclick: () => { viewing = null; draw(); } }),
                    T.el('span', { class: 'muted small', text: T.date(p.created_at) }),
                    T.el('span', { text: `${viewing + 1} / ${photos.length}`, class: 'small muted' }),
                ]),
                T.el('div', { class: 'viewer-img' }, [
                    T.el('button', { class: 'viewer-nav', html: T.icon('left'), onclick: () => go(-1) }),
                    T.el('img', { src: p.url }),
                    T.el('button', { class: 'viewer-nav', html: T.icon('right'), onclick: () => go(1) }),
                ]),
                T.el('div', { class: 'row pad', style: { justifyContent: 'center' } }, [
                    T.el('button', { class: 'btn primary', text: 'Poner de fondo', onclick: () => { T.saveSettings({ wallpaper: p.url }); T.toast('Fondo aplicado', 'ok'); } }),
                    T.el('button', { class: 'btn danger', html: T.icon('trash'), title: 'Eliminar', onclick: () => { T.req('gallery:delete', { id: p.id }); viewing = null; } }),
                ]),
            ]));
            return;
        }

        body.append(T.el('div', { class: 'grow scroll pad' }, [
            T.el('div', { class: 'row between', style: { marginBottom: '10px' } }, [T.el('div', { class: 'h2', text: 'Recientes' }), T.el('span', { class: 'muted small', text: `${photos.length} fotos` })]),
            T.el('div', { class: 'gal-grid' }, photos.map((p, i) => T.el('button', { class: 'gal-item', onclick: () => { viewing = i; draw(); } }, T.el('img', { src: p.url, loading: 'lazy' })))),
        ]));
    }

    T.on('push:gallery', (rows) => { photos = rows || []; draw(); });
    T.on('push:photo', () => { photos = null; });

    T.app({
        id: 'gallery', name: 'Fotos', icon: 'image', color: 'linear-gradient(160deg,#ffcc00,#ff9500 40%,#ff2d55 70%,#5856d6)', dock: true,
        render(el) {
            root = el;
            viewing = null;
            el.append(T.el('div', { class: 'app-title', text: 'Fotos' }), T.el('div', { class: 'app-body' }));
            draw();
            if (photos === null) T.req('gallery:list');
        },
    });
})();
