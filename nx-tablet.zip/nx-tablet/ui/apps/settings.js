/* Ajustes: modo avión/streamer, notificaciones, sonidos, brillo, fondo y marco */
(() => {
    const MENU = [
        { id: 'notifications', name: 'Notificaciones', sub: 'Avisos de las apps', icon: 'bell', color: '#ff453a' },
        { id: 'sounds', name: 'Sonidos', sub: 'Sonidos de la interfaz', icon: 'volume', color: '#ff2d78' },
        { id: 'general', name: 'General', sub: 'Información y restablecer', icon: 'settings', color: '#8e8e93' },
        { id: 'display', name: 'Pantalla y brillo', sub: 'Brillo de la pantalla', icon: 'sun', color: '#0a84ff' },
        { id: 'wallpaper', name: 'Fondo y marco', sub: 'Fondo de pantalla y marco', icon: 'image', color: '#32ade6' },
    ];
    let section = 'wallpaper';
    let root = null;
    let resetArmed = false;

    const s = () => T.state.settings;
    const sw = (key) => T.el('button', { class: 'switch' + (s()[key] ? ' on' : ''), onclick: () => { T.saveSettings({ [key]: !s()[key] }); draw(); } });
    const row = (title, sub, right) => T.el('div', { class: 'set-row' }, [T.el('div', [T.el('b', title), sub ? T.el('div', { class: 'small muted', text: sub }) : null]), right]);
    const icon = (m) => T.el('span', { class: 'set-ico', html: T.icon(m.icon), style: { background: m.color } });

    function side() {
        const p = T.state.player;
        return T.el('div', { class: 'set-side scroll' }, [
            T.el('div', { class: 'card set-profile', onclick: () => T.openApp('profile') }, [
                T.el('div', { class: 'avatar', text: (p.name || '?')[0] }),
                T.el('div', [T.el('b', { class: 'sensitive', text: p.name || '' }), T.el('div', { class: 'small muted', text: p.job || '' })]),
            ]),
            T.el('div', { class: 'small muted set-label', text: 'AJUSTES' }),
            T.el('div', { class: 'card' }, [
                T.el('div', { class: 'set-item' }, [icon({ icon: 'plane', color: '#ff9f0a' }), T.el('div', { class: 'grow' }, [T.el('b', 'Modo avión'), T.el('div', { class: 'small muted', text: 'Silencia los avisos' })]), sw('airplane')]),
                T.el('div', { class: 'set-item' }, [icon({ icon: 'eyeoff', color: '#bf5af2' }), T.el('div', { class: 'grow' }, [T.el('b', 'Modo streamer'), T.el('div', { class: 'small muted', text: 'Difumina información sensible' })]), sw('streamer')]),
            ]),
            T.el('div', { class: 'card' }, MENU.map((m) => T.el('button', { class: 'set-item' + (m.id === section ? ' on' : ''), onclick: () => { section = m.id; resetArmed = false; draw(); } }, [
                icon(m), T.el('div', { class: 'grow' }, [T.el('b', m.name), T.el('div', { class: 'small muted', text: m.sub })]), T.el('span', { class: 'muted', html: T.icon('right'), style: { width: '14px' } }),
            ]))),
        ]);
    }

    const SECTIONS = {
        notifications: () => [T.el('div', { class: 'card' }, [row('Permitir notificaciones', 'Alarmas, temporizador y fotos', sw('notifications'))])],
        sounds: () => [T.el('div', { class: 'card' }, [
            row('Sonidos de la interfaz', 'Toques, desbloqueo y avisos', sw('sounds')),
            row('Volumen', `${s().volume}%`, T.el('input', { type: 'range', min: 0, max: 100, value: s().volume, style: { width: '45%' }, onchange: (e) => { T.saveSettings({ volume: Number(e.target.value) }); draw(); } })),
            T.el('div', { class: 'pad' }, T.el('button', { class: 'btn primary', text: 'Probar sonido', onclick: () => T.beep(880, 200, true) })),
        ])],
        general: () => [
            T.el('div', { class: 'card' }, [
                row('Modelo', null, T.el('span', { class: 'muted', text: 'NX Tablet Pro' })),
                row('Versión', null, T.el('span', { class: 'muted', text: '1.0.0' })),
                row('Propietario', null, T.el('span', { class: 'muted sensitive', text: T.state.player.name || '' })),
            ]),
            T.el('div', { class: 'card' }, [row('Restablecer ajustes', 'Vuelve a los valores de fábrica', T.el('button', {
                class: 'btn danger', text: resetArmed ? '¿Seguro? Pulsa otra vez' : 'Restablecer',
                onclick: () => {
                    if (!resetArmed) { resetArmed = true; draw(); return; }
                    resetArmed = false;
                    T.req('settings:reset').then((r) => { if (r.ok) { T.state.settings = r.settings; T.applySettings(); T.toast('Ajustes restablecidos', 'ok'); draw(); } });
                },
            }))]),
        ],
        display: () => [T.el('div', { class: 'card' }, [row('Brillo', `${s().brightness}%`, T.el('input', {
            type: 'range', min: 20, max: 100, value: s().brightness, style: { width: '45%' },
            oninput: (e) => T.saveSettings({ brightness: Number(e.target.value) }), onchange: draw,
        }))])],
        wallpaper: () => {
            let url = '';
            return [
                T.el('div', { class: 'small muted set-label', text: 'FONDOS DE PANTALLA' }),
                T.el('div', { class: 'wp-grid' }, T.WALLPAPERS.map((w) => T.el('button', {
                    class: 'wp' + (s().wallpaper === w.id ? ' on' : ''), style: { background: w.css }, text: w.name,
                    onclick: () => { T.saveSettings({ wallpaper: w.id }); T.toast('Fondo aplicado', 'ok'); draw(); },
                }))),
                T.el('div', { class: 'card row pad' }, [
                    T.el('input', { class: 'grow', placeholder: 'URL de imagen (https://...)', oninput: (e) => { url = e.target.value.trim(); } }),
                    T.el('button', { class: 'btn primary', text: 'Usar', onclick: () => { if (/^https:\/\//.test(url)) { T.saveSettings({ wallpaper: url }); T.toast('Fondo aplicado', 'ok'); } else T.toast('URL no válida', 'err'); } }),
                    T.el('button', { class: 'btn', text: 'Desde la galería', onclick: () => T.openApp('gallery') }),
                ]),
                T.el('div', { class: 'small muted set-label', text: 'MARCO' }),
                T.el('div', { class: 'wp-grid' }, T.FRAMES.map((f) => T.el('button', {
                    class: 'wp frame-opt' + (s().frame === f.id ? ' on' : '') + (f.id === 'rainbow' ? ' rainbow' : ''),
                    style: { borderColor: f.color === 'transparent' ? 'rgba(255,255,255,.15)' : f.color, color: f.color === 'transparent' ? '' : f.color }, text: f.name,
                    onclick: () => { T.saveSettings({ frame: f.id }); draw(); },
                }))),
            ];
        },
    };

    function draw() {
        if (!T.showing('settings')) return;
        const body = T.clear(T.$('.app-body', root));
        const m = MENU.find((x) => x.id === section);
        body.append(side(), T.el('div', { class: 'set-main scroll' }, [T.el('div', { class: 'h2', text: m.name }), ...SECTIONS[section]()]));
    }

    T.app({
        id: 'settings', name: 'Ajustes', icon: 'settings', color: 'linear-gradient(160deg,#8e8e93,#48484a)', dock: true,
        render(el) {
            root = el;
            el.append(T.el('div', { class: 'app-title', text: 'Ajustes' }), T.el('div', { class: 'app-body' }));
            draw();
        },
    });
})();
