/* Calculadora */
(() => {
    let cur = '0';
    let prev = null;
    let op = null;
    let fresh = true;

    const calc = (a, b, o) => ({ '+': a + b, '−': a - b, '×': a * b, '÷': b === 0 ? NaN : a / b })[o];
    const show = (n) => (Number.isFinite(n) ? String(parseFloat(n.toPrecision(12))) : 'Error');

    function press(k, out) {
        if (/^\d$/.test(k)) { cur = fresh || cur === '0' ? k : cur + k; fresh = false; }
        else if (k === ',') { if (fresh) { cur = '0.'; fresh = false; } else if (!cur.includes('.')) cur += '.'; }
        else if (k === 'C') { cur = '0'; prev = null; op = null; fresh = true; }
        else if (k === '±') cur = show(-Number(cur));
        else if (k === '%') cur = show(Number(cur) / 100);
        else if (k === '=') { if (op !== null) { cur = show(calc(prev, Number(cur), op)); op = null; prev = null; fresh = true; } }
        else { if (op !== null && !fresh) cur = show(calc(prev, Number(cur), op)); prev = Number(cur); op = k; fresh = true; }
        out.textContent = cur.replace('.', ',');
    }

    const KEYS = ['C', '±', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '−', '1', '2', '3', '+', '0', ',', '='];

    T.app({
        id: 'calculator', name: 'Calculadora', icon: 'calc', color: 'linear-gradient(160deg,#ff9f0a,#ff6a00)',
        render(el) {
            const out = T.el('div', { class: 'calc-out', text: cur.replace('.', ',') });
            el.append(T.el('div', { class: 'app-title', text: 'Calculadora' }), T.el('div', { class: 'calc' }, [
                out,
                T.el('div', { class: 'calc-keys' }, KEYS.map((k) => T.el('button', {
                    class: 'calc-k' + (/[÷×−+=]/.test(k) ? ' op' : '') + (/[C±%]/.test(k) ? ' fn' : '') + (k === '0' ? ' zero' : ''),
                    text: k, onclick: () => { T.beep(1400, 15); press(k, out); },
                }))),
            ]));
        },
    });
})();
