/* Música: búsqueda en YouTube, playlists (propias y compartidas), cola y
   salida de audio (tablet, radio del coche o boombox). El audio lo reproduce
   xsound en el cliente; aquí solo se manda qué tocar. */
(() => {
    const M = {
        view: 'browse', query: '', results: [], loading: false, searched: false,
        playlists: [], recent: [], queue: [], index: -1, shuffle: false, repeat: false,
        devicesOpen: false, devices: [], picking: null, creating: false,
    };
    let bar = null; // refs del reproductor para actualizar el progreso sin repintar

    /* ── Reproducción ── */
    function play(list, i) {
        M.queue = list.slice();
        M.index = i;
        const track = M.queue[i];
        if (!track) return;
        M.recent = [track, ...M.recent.filter((t) => t.id !== track.id)].slice(0, 30);
        T.req('music:play', { track }).then((r) => { if (!r.ok) T.toast(r.error || 'No se pudo reproducir', 'err'); });
    }

    function step(dir) {
        if (!M.queue.length) return;
        let i = M.shuffle ? Math.floor(Math.random() * M.queue.length) : M.index + dir;
        if (i >= M.queue.length) { if (!M.repeat) { T.req('music:stop'); return; } i = 0; }
        if (i < 0) i = M.queue.length - 1;
        play(M.queue, i);
    }

    T.on('ended', () => step(1));

    function search(q) {
        M.query = q; M.view = 'browse'; M.loading = true; M.searched = true; draw();
        T.req('music:search', { q }).then((r) => {
            M.loading = false;
            if (!r.ok) T.toast(r.error || 'Error al buscar', 'err');
            M.results = r.results || [];
            draw();
        });
    }

    const setPlaylists = (r) => { if (r && r.ok) { M.playlists = r.playlists || []; draw(); } else if (r && r.error) T.toast(r.error, 'err'); };

    /* ── Piezas ── */
    function trackCard(list, i, opts) {
        const t = list[i];
        const playing = T.state.music && T.state.music.track && T.state.music.track.id === t.id;
        return T.el('div', { class: 'mus-card' + (playing ? ' on' : '') }, [
            T.el('div', { class: 'mus-thumb', onclick: () => play(list, i) }, [
                T.el('img', { src: t.thumb, loading: 'lazy' }),
                t.duration ? T.el('span', { class: 'mus-dur', text: t.duration }) : null,
                T.el('span', { class: 'mus-playbtn', html: T.icon('play') }),
            ]),
            T.el('div', { class: 'mus-meta' }, [
                T.el('div', { class: 'grow', style: { minWidth: 0 } }, [T.el('b', { text: t.title }), T.el('div', { class: 'small muted', text: t.author || '' })]),
                opts && opts.remove
                    ? T.el('button', { class: 'mus-mini', html: T.icon('trash'), title: 'Quitar', onclick: opts.remove })
                    : T.el('button', { class: 'mus-mini', html: T.icon('plus'), title: 'Añadir a playlist', onclick: () => { M.picking = t; draw(); } }),
            ]),
        ]);
    }

    function sidebar() {
        const mine = M.playlists.filter((p) => p.mine);
        const shared = M.playlists.filter((p) => !p.mine);
        const item = (view, label, icon) => T.el('button', { class: 'mus-nav' + (M.view === view ? ' on' : ''), onclick: () => { M.view = view; draw(); } }, [icon ? T.el('span', { html: T.icon(icon) }) : null, label]);
        const nameInput = T.el('input', { placeholder: 'Nombre', maxlength: 48 });
        return T.el('div', { class: 'mus-side scroll' }, [
            T.el('div', { class: 'mus-logo' }, [T.el('span', { html: T.icon('music') }), 'Música']),
            item('browse', 'Explorar', 'search'),
            item('recent', 'Recientes', 'clock'),
            T.el('div', { class: 'small muted mus-label', text: 'BIBLIOTECA' }),
            ...mine.map((p) => item('pl:' + p.id, p.name + (p.shared ? ' ·' : ''), 'list')),
            M.creating
                ? T.el('div', { class: 'mus-create' }, [nameInput, T.el('button', {
                    class: 'btn primary', text: 'Crear',
                    onclick: () => { M.creating = false; T.req('playlists:create', { name: nameInput.value.trim() }).then(setPlaylists); },
                })])
                : T.el('button', { class: 'mus-nav mus-new', onclick: () => { M.creating = true; draw(); setTimeout(() => nameInput.focus(), 0); } }, [T.el('span', { html: T.icon('plus') }), 'Nueva playlist']),
            shared.length ? T.el('div', { class: 'small muted mus-label', text: 'COMPARTIDAS' }) : null,
            ...shared.map((p) => item('pl:' + p.id, `${p.name} · ${p.owner_name}`, 'share')),
        ]);
    }

    function browse() {
        const input = T.el('input', { class: 'grow', placeholder: 'Busca canciones o pega un enlace de YouTube…', value: M.query, onkeydown: (e) => { if (e.key === 'Enter') search(input.value.trim()); } });
        return [
            T.el('div', { class: 'row between' }, [
                T.el('div', [T.el('div', { class: 'h2', text: M.searched && M.query ? `“${M.query}”` : 'Tendencias' }), T.el('div', { class: 'small muted', text: 'Pulsa una canción para reproducirla o + para añadirla a una playlist' })]),
                M.results.length ? T.el('button', { class: 'btn mus-pink', html: T.icon('play') + ' Reproducir', onclick: () => play(M.results, 0) }) : null,
            ]),
            T.el('div', { class: 'row mus-search' }, [input, T.el('button', { class: 'btn mus-pink', text: 'Buscar', onclick: () => search(input.value.trim()) })]),
            M.loading ? T.el('div', { class: 'empty', text: 'Buscando…' })
                : (M.results.length ? T.el('div', { class: 'mus-grid' }, M.results.map((_, i) => trackCard(M.results, i)))
                    : T.el('div', { class: 'empty', text: M.searched ? 'Sin resultados' : 'Busca algo para empezar' })),
        ];
    }

    function recent() {
        return [T.el('div', { class: 'h2', text: 'Recientes' }), M.recent.length
            ? T.el('div', { class: 'mus-grid' }, M.recent.map((_, i) => trackCard(M.recent, i)))
            : T.el('div', { class: 'empty', text: 'Aún no has escuchado nada' })];
    }

    function playlist(id) {
        const p = M.playlists.find((x) => String(x.id) === id);
        if (!p) return [T.el('div', { class: 'empty', text: 'Playlist no encontrada' })];
        return [
            T.el('div', { class: 'row between' }, [
                T.el('div', [T.el('div', { class: 'small muted', text: p.mine ? 'PLAYLIST' : 'COMPARTIDA' }), T.el('div', { class: 'h1', text: p.name }), T.el('div', { class: 'small muted', text: `${p.tracks.length} canciones · ${p.owner_name}${p.shared ? ' · compartida con la comunidad' : ''}` })]),
                T.el('div', { class: 'row' }, [
                    p.mine ? T.el('button', { class: 'btn', text: p.shared ? 'Dejar de compartir' : 'Compartir', onclick: () => T.req('playlists:share', { id: p.id, shared: !p.shared }).then(setPlaylists) }) : null,
                    p.mine ? T.el('button', { class: 'btn danger', text: 'Eliminar', onclick: () => { M.view = 'browse'; T.req('playlists:delete', { id: p.id }).then(setPlaylists); } }) : null,
                    p.tracks.length ? T.el('button', { class: 'btn mus-pink', html: T.icon('play') + ' Reproducir', onclick: () => play(p.tracks, 0) }) : null,
                ]),
            ]),
            p.tracks.length
                ? T.el('div', { class: 'mus-grid' }, p.tracks.map((t, i) => trackCard(p.tracks, i, p.mine ? { remove: () => T.req('playlists:remove', { id: p.id, trackId: t.id }).then(setPlaylists) } : null)))
                : T.el('div', { class: 'empty', text: 'Vacía. Añade canciones con + desde Explorar.' }),
        ];
    }

    function picker() {
        const mine = M.playlists.filter((p) => p.mine);
        return T.el('div', { class: 'mus-sheet', onclick: () => { M.picking = null; draw(); } }, T.el('div', { class: 'mus-sheet-box card', onclick: (e) => e.stopPropagation() }, [
            T.el('b', 'Añadir a playlist'), T.el('div', { class: 'small muted', text: M.picking.title }),
            ...(mine.length ? mine.map((p) => T.el('button', {
                class: 'mus-nav', text: p.name,
                onclick: () => { const t = M.picking; M.picking = null; T.req('playlists:add', { id: p.id, track: t }).then((r) => { setPlaylists(r); if (r.ok) T.toast('Añadida a ' + p.name, 'ok'); }); },
            })) : [T.el('div', { class: 'muted small', text: 'Crea una playlist primero' })]),
            T.el('button', { class: 'btn', text: 'Cancelar', onclick: () => { M.picking = null; draw(); } }),
        ]));
    }

    function devicesPanel() {
        const cur = (T.state.music && T.state.music.target) || {};
        return T.el('div', { class: 'mus-devices scroll' }, [
            T.el('div', { class: 'row between' }, [T.el('div', [T.el('div', { class: 'small', style: { color: 'var(--pink)' }, text: 'BLUETOOTH' }), T.el('b', 'Dispositivos de audio')]), T.el('button', { class: 'mus-mini', html: T.icon('x'), onclick: () => { M.devicesOpen = false; draw(); } })]),
            ...M.devices.map((d) => {
                const active = cur.kind === d.kind && (d.kind === 'ped' || cur.net === d.net);
                return T.el('button', {
                    class: 'mus-dev' + (active ? ' on' : ''),
                    onclick: () => T.req('music:output', { kind: d.kind, net: d.net }).then((r) => { if (r.ok) T.toast('Conectado a ' + d.label, 'ok'); else T.toast(r.error || 'No se pudo conectar', 'err'); }),
                }, [T.el('span', { html: T.icon(d.kind === 'ped' ? 'volume' : 'bluetooth') }), T.el('div', { class: 'grow' }, [T.el('b', d.label), T.el('div', { class: 'small muted', text: active ? 'Conectado' : d.sub })])]);
            }),
            T.el('div', { class: 'small muted', text: 'Súbete a un coche para usar su radio, o coloca una boombox (item) cerca y aparecerá aquí.' }),
            T.el('button', { class: 'btn', text: 'Buscar dispositivos', onclick: refreshDevices }),
        ]);
    }

    function refreshDevices() {
        T.client('music:devices').then((r) => { M.devices = (r && r.devices) || []; draw(); });
    }

    function player() {
        const m = T.state.music;
        const p = T.state.progress;
        const fill = T.el('i');
        const time = T.el('span', { class: 'small muted' });
        const seek = T.el('div', {
            class: 'mus-seek',
            onclick: (e) => { const r = seek.getBoundingClientRect(); if (p.duration > 0) T.req('music:seek', { time: ((e.clientX - r.left) / r.width) * T.state.progress.duration }); },
        }, fill);
        bar = { fill, time };
        const btn = (icon, fn, on) => T.el('button', { class: 'mus-ctl' + (on ? ' on' : ''), html: T.icon(icon), onclick: fn });

        const el = T.el('div', { class: 'mus-player' }, [
            T.el('div', { class: 'row mus-now' }, m && m.track
                ? [T.el('img', { src: m.track.thumb }), T.el('div', { style: { minWidth: 0 } }, [T.el('b', m.track.title), T.el('div', { class: 'small muted', text: T.outputName(m.target) })])]
                : [T.el('div', { class: 'mus-ph', html: T.icon('music') }), T.el('div', [T.el('b', 'Sin canción'), T.el('div', { class: 'small muted', text: 'Preparada' })])]),
            T.el('div', { class: 'mus-center' }, [
                T.el('div', { class: 'row', style: { justifyContent: 'center', gap: '14px' } }, [
                    btn('shuffle', () => { M.shuffle = !M.shuffle; draw(); }, M.shuffle),
                    btn('prev', () => step(-1)),
                    T.el('button', { class: 'mus-play', html: T.icon(m && !m.paused ? 'pause' : 'play'), onclick: () => { if (!m) { if (M.results.length) play(M.results, 0); return; } T.req(m.paused ? 'music:resume' : 'music:pause'); } }),
                    btn('next', () => step(1)),
                    btn('repeat', () => { M.repeat = !M.repeat; draw(); }, M.repeat),
                ]),
                T.el('div', { class: 'row' }, [seek, time]),
            ]),
            T.el('div', { class: 'row mus-right' }, [
                T.el('span', { html: T.icon('volume'), style: { width: '16px' } }),
                T.el('input', { type: 'range', min: 0, max: 100, value: Math.round((m ? m.volume : T.state.config.defaultVolume) * 100), onchange: (e) => T.req('music:volume', { volume: Number(e.target.value) / 100 }) }),
                btn('bluetooth', () => { M.devicesOpen = !M.devicesOpen; if (M.devicesOpen) refreshDevices(); draw(); }, M.devicesOpen),
                m ? T.el('button', { class: 'btn small', text: 'Parar', onclick: () => T.req('music:stop') }) : null,
            ]),
        ]);
        progress();
        return el;
    }

    function progress() {
        if (!bar) return;
        const p = T.state.progress;
        bar.fill.style.width = (p.duration > 0 ? Math.min(100, (p.time / p.duration) * 100) : 0) + '%';
        bar.time.textContent = `${T.secs(p.time)} / ${T.secs(p.duration)}`;
    }

    function draw() {
        if (!T.showing('music')) return;
        let main;
        if (M.view === 'recent') main = recent();
        else if (M.view.startsWith('pl:')) main = playlist(M.view.slice(3));
        else main = browse();

        T.clear(T.$('#app')).append(
            T.el('div', { class: 'app-title', text: 'Música' }),
            T.el('div', { class: 'mus' }, [
                sidebar(),
                T.el('div', { class: 'mus-main scroll' }, main),
                M.devicesOpen ? devicesPanel() : null,
                M.picking ? picker() : null,
            ]),
            player(),
        );
    }

    T.on('music', () => { if (T.showing('music')) draw(); });
    T.on('progress', progress);

    T.app({
        id: 'music', name: 'Música', icon: 'music', color: 'linear-gradient(160deg,#ff375f,#c2185b)', dock: true,
        render(el) {
            el.style.background = 'linear-gradient(180deg,#2a0c1d,#14060e 40%,#0d0409)';
            draw();
            T.req('playlists:list').then(setPlaylists);
            if (!M.searched && !M.results.length) {
                M.loading = true;
                T.req('music:search', { q: T.state.config.trending || 'top hits' }).then((r) => { M.loading = false; M.results = r.results || []; draw(); });
            }
        },
        onClose() { bar = null; },
    });
})();
