/* Cámara: el cliente Lua toma el control (cámara del juego + screenshot-basic).
   La interfaz solo muestra el overlay (#camui, ver core.js). */
T.app({
    id: 'camera', name: 'Cámara', icon: 'camera', color: 'linear-gradient(160deg,#636366,#1c1c1e)', dock: true,
    render(el) {
        el.append(T.el('div', { class: 'empty', text: 'Abriendo cámara…' }));
        T.client('camera');
    },
});

T.on('push:photo', () => T.notify('Foto guardada en la galería'));
